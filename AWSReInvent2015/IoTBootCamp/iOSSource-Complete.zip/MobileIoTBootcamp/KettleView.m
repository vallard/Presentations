//
//  ControlPanelView.m
//  MobileIoTBootcamp
//
//  Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License").
//  You may not use this file except in compliance with the License.
//  A copy of the License is located at
//
//  http://aws.amazon.com/apache2.0
//
//  or in the "license" file accompanying this file. This file is distributed
//  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
//  express or implied. See the License for the specific language governing
//  permissions and limitations under the License.
//
//  This source code forms part of the codebase for the re:Invent 2015 Bootcamp - "Creating applications for Mobile and IoT"
//
//  Created by Richard Threlkeld on 7/20/15.
//

#import "KettleView.h"
#import "AWSCore.h"
#import "AWSCognito.h"
#import <AWSMobileAnalytics/AWSMobileAnalytics.h>
#import "AWSClientHelper.h"


const float BOILTIME_MIN = 10;
const float BOILTIME_MAX = 60;
const float BOILTEMP_MIN = 10;
const float BOILTEMP_MAX = 100;

@implementation KettleView

@synthesize waterTempKey;
@synthesize boilDurationKey;

- (void)viewDidLoad{
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(CognitoSyncUpdate) name:@"CognitoSyncUpdate" object:nil];
    
    NSMutableString *waterTemp = [NSMutableString stringWithFormat:
                                  [NSBundle mainBundle].bundleIdentifier];
    [waterTemp appendString:@".waterTemp"];
    
    NSMutableString *boilDuration = [NSMutableString stringWithFormat:
                                     [NSBundle mainBundle].bundleIdentifier];
    [boilDuration appendString:@".boilDuration"];
    
    waterTempKey = [NSString stringWithString:waterTemp];
    boilDurationKey = [NSString stringWithString:boilDuration];

    AWSCognito *syncClient = [AWSCognito defaultCognito];
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
    AWSCognitoDataset *dataset = [syncClient openOrCreateDataset:
                                  [preferences objectForKey:@"uniqueDatasetName"]];
    [dataset synchronize];
    
    self.waterTemp.maximumValue = (int)(BOILTEMP_MAX - BOILTEMP_MIN);
    self.boilDuration.maximumValue = (int)(BOILTIME_MAX - BOILTIME_MIN);
    
    self.waterTemp.value = [self calcTempValueSliderFromCognito:
                            [dataset stringForKey:waterTempKey].intValue];
    
    self.boilDuration.value = [self calcBoilTimeSliderFromCognito:
                               [dataset stringForKey:boilDurationKey].intValue];
    
    self.tempSettingLabel.text = [NSString stringWithFormat:@"%d", (int)[self calcTempValueSliderFromCognito:[dataset stringForKey:waterTempKey].intValue]];
    
    self.timeSettingLabel.text = [NSString stringWithFormat:@"%d", (int)[self calcBoilTimeSliderFromCognito:[dataset stringForKey:boilDurationKey].intValue]];
}

- (void) viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:NO];
}

- (int) calcBoilTimeSliderProgress:(float)progress{
    return (int)(BOILTIME_MIN + progress);
}

- (float) calcBoilTimeSliderFromCognito:(int)time{
    return (time - BOILTIME_MIN);
}

- (int) calcTempValueSliderProgress:(float)progress{
    return (int)(BOILTEMP_MIN + progress);
}

- (float) calcTempValueSliderFromCognito:(int)time{
    return (time - BOILTEMP_MIN);
}

-(void)CognitoSyncUpdate
{
    AWSCognito *syncClient = [AWSCognito defaultCognito];
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
    AWSCognitoDataset *dataset = [syncClient openOrCreateDataset:[preferences objectForKey:@"uniqueDatasetName"]];
    [dataset synchronize];
    
    self.waterTemp.value = [dataset stringForKey:waterTempKey].floatValue;
    self.boilDuration.value = [dataset stringForKey:boilDurationKey].floatValue;
    self.tempSettingLabel.text = [NSString stringWithFormat:@"%d",[dataset stringForKey:waterTempKey].intValue];
    self.timeSettingLabel.text = [NSString stringWithFormat:@"%d",[dataset stringForKey:boilDurationKey].intValue];
}

- (IBAction)returnToDeviceScreen:(id)sender {
    [self.presentingViewController dismissViewControllerAnimated:YES completion:NULL];
}

- (IBAction)controlPanelValueChanged:(id)sender{
    NSLog(@"Setting local dataset values \nwaterTemp: %d\nboilDuration: %d",(int)self.waterTemp.value,(int)self.boilDuration.value);
    AWSCognito *syncClient = [AWSCognito defaultCognito];
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
    AWSCognitoDataset *dataset = [syncClient openOrCreateDataset:[preferences objectForKey:@"uniqueDatasetName"]];
    
    [dataset setString:[NSString stringWithFormat:@"%d",(int)self.waterTemp.value] forKey:waterTempKey];
    [dataset setString:[NSString stringWithFormat:@"%d",(int)self.boilDuration.value] forKey:boilDurationKey];
    self.tempSettingLabel.text = [NSString stringWithFormat:@"%d",(int)self.waterTemp.value];
    self.timeSettingLabel.text = [NSString stringWithFormat:@"%d",(int)self.boilDuration.value];
}

- (NSString*)getPanelNameForAnalytics{
    return @"KettleControlPanel";
}

- (IBAction)updateButton:(id)sender {
    AWSCognito *syncClient = [AWSCognito defaultCognito];
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
	
	//Sync Cognito Dataset
	AWSCognitoDataset *dataset = [syncClient openOrCreateDataset:[preferences objectForKey:@"uniqueDatasetName"]];
	NSLog(@"Synchronizing dataset with Cognito");
	[dataset synchronize];
	
	//Send data to Mobile Analytics
	AWSMobileAnalytics *analytics = [[AWSClientHelper sharedInstance] analytics:[preferences objectForKey:@"mobileanalyticsAppId"]];
	id<AWSMobileAnalyticsEventClient> eventClient = analytics.eventClient;
	id<AWSMobileAnalyticsEvent> customEvent = [eventClient createEventWithEventType:[self getPanelNameForAnalytics]];
	
	[customEvent addMetric:[NSNumber numberWithFloat:
							[self calcTempValueSliderProgress:
							 self.waterTemp.value]] forKey:@"MaxTemp"];
	
	[customEvent addMetric:[NSNumber numberWithFloat:
							[self calcBoilTimeSliderProgress:
							 self.boilDuration.value]] forKey:@"BoilTime"];
	
	[eventClient recordEvent:customEvent];
	NSLog(@"Sending temperature and boil events to Moble Analytics");
	[eventClient submitEvents];
	
}


@end
