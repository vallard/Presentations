//
//  InfoViewController.m
//  MobileIoTBootcamp
//
//  Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License").
//  You may not use this file except in compliance with the License.
//  A copy of the License is located at
//
//  http://aws.amazon.com/apache2.0
//
//  or in the "license" file accompanying this file. This file is distributed
//  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
//  express or implied. See the License for the specific language governing
//  permissions and limitations under the License.
//
//  This source code forms part of the codebase for the re:Invent 2015 Bootcamp - "Creating applications for Mobile and IoT"
//
//  Created by Richard Threlkeld on 7/20/15.
//

#import "InfoViewController.h"
#import <AWSCore/AWSCore.h>
#import <AWSSNS/AWSSNS.h>
#import <AWSDynamoDB/AWSDynamoDB.h>
#import <AWSDynamoDBModel.h>
#import "DDBDynamoDBManager.h"
#import <AWSSQS/AWSSQS.h>

@interface InfoViewController ()

@property (nonatomic, readonly) NSMutableArray *tableRows;
@property (nonatomic, readonly) NSLock *lock;
@property (nonatomic, strong) NSDictionary *lastEvaluatedKey;
@property (nonatomic, assign) BOOL doneLoading;

@end

const int SECOND_MILLIS = 1000;
const int MINUTE_MILLIS = 60 * SECOND_MILLIS;
const int HOUR_MILLIS = 60 * MINUTE_MILLIS;
const int DAY_MILLIS = 24 * HOUR_MILLIS;

@implementation InfoViewController

- (IBAction)refreshButton:(id)sender {
    [self refreshList:YES];
    [self.listTableView setContentOffset:CGPointZero animated:YES];
    [self.listTableView reloadData];
}

- (void)viewDidLoad{
    [super viewDidLoad];
    //[AWSLogger defaultLogger].logLevel = AWSLogLevelVerbose;
    self.listTableView.delegate = self;
    self.listTableView.delegate = self;
    
    //Hide registration message and register for SNS driven notification set in AppDelegate
    [self.snsConfirmationMsg setHidden:YES];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showConfirmationMessage) name:@"showSNSPublish" object:nil];
    
    //Set top view with tethered data
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
    self.edisonName.text = [preferences objectForKey:@"name"];
    self.ipAddressValue.text = [preferences objectForKey:@"ipAddress"];
    self.accountIdValue.text = [preferences objectForKey:@"accountId"];
    self.applianceUUIDValue.text = [preferences objectForKey:@"applianceId"];
    self.applianceTypeValue.text = [self getApplianceName:[preferences objectForKey:@"applianceType"]];
    [self.applianceImage setImage:[UIImage imageNamed:[self getApplianceImage:[preferences objectForKey:@"applianceType"]]]];
    
    NSLog(@"Setting cognitoIdentityIdValue: %@",[[AWSClientHelper sharedInstance] cognitoID]);
    self.cognitoIdentityIdValue.text = [[AWSClientHelper sharedInstance] getIdentityId];
    
    [self refreshList:YES];
    [self.listTableView setContentOffset:CGPointZero animated:YES];

    [self.listTableView reloadData];
    
    //Phone already tethered if cognitoIdentityPoolId not nil
    if ([preferences objectForKey:@"cognitoIdentityPoolId"]){
    
        NSLog(@"Attempting to create new SNS endpoint and add to topic");
        AWSSNS *sns = [AWSSNS defaultSNS];
        AWSSNSCreatePlatformEndpointInput *request = [AWSSNSCreatePlatformEndpointInput new];
        request.token = [preferences objectForKey:@"deviceToken"];
        request.platformApplicationArn = [preferences objectForKey:@"snsArnPlatformApplication"];
        
        //Add Endpoint to App Push SNS Platform Application
        [[sns createPlatformEndpoint:request] continueWithBlock:^id(AWSTask *task) {
            if (task.error != nil) {
                NSLog(@"Error: %@",task.error);
            } else {
                AWSSNSCreateEndpointResponse *createEndPointResponse = task.result;
                NSLog(@"createEndPointResponse: %@",createEndPointResponse);
                [preferences setObject:createEndPointResponse.endpointArn forKey:@"endpointArn"];
                
                //Now add created Endpoint to topic
                AWSSNSSubscribeInput *subscribe = [AWSSNSSubscribeInput new];
                subscribe.endpoint = createEndPointResponse.endpointArn;
                subscribe.protocols = @"application";
                subscribe.topicArn = [preferences objectForKey:@"snsArnTopicToMobile"];
                [[sns subscribe:subscribe] continueWithBlock:^id(AWSTask *task) {
                    if (task.error){
                        NSLog(@"Error: %@",task.error);
                    }else{
                        AWSSNSSubscribeResponse *subscribeResponse = task.result;
                        NSLog(@"subscriptionARN: %@",subscribeResponse);
                        [preferences setObject:subscribeResponse.subscriptionArn forKey:@"snsSubscriptionId"];
                        
                        //Publish a test message to SNS upon registration to validate configuration
                        AWSSNSPublishInput *publishInput = [AWSSNSPublishInput new];
                        publishInput.targetArn = [preferences objectForKey:@"endpointArn"];
                        
                        NSDictionary *publishPacket = @{@"body":@"SUBPUBLISHSUCCESS",
                                                 @"messageType":[NSNumber numberWithInt:3]};
                        NSError *error;
                        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:publishPacket
                                                                           options:0
                                                                             error:&error];
                        
                        publishInput.message = [[NSString alloc] initWithBytes:[jsonData bytes] length:[jsonData length] encoding:NSUTF8StringEncoding];
                        
                        [[sns publish:publishInput] continueWithBlock:^id(AWSTask *task) {
                            if (task.error){
                                NSLog(@"SNSpublishError: %@",task.error);
                            }else{
                                NSLog(@"SNSpublishResult: %@",task.result);
                            }
                            return nil;
                        }];
                    }
                    return nil;
                }];

                //Add Endpoint to Cognito Sync SNS Platform Application
                request.platformApplicationArn = [preferences objectForKey:@"snsArnPlatformApplicationCognitoSync"];
                [[sns createPlatformEndpoint:request] continueWithBlock:^id(AWSTask *task) {
                    if (task.error) {
                        NSLog(@"Error: %@",task.error);
                    }else{
                        AWSSNSCreateEndpointResponse *cognitySyncEndPointResponse = task.result;
                        NSLog(@"cognitySyncEndPointResponse: %@",cognitySyncEndPointResponse);
                        [preferences setObject:cognitySyncEndPointResponse.endpointArn forKey:@"cognitoSyncEndpointArn"];
                    }
                    return nil;
                }];
                
                
                [[NSUserDefaults standardUserDefaults] synchronize];    //Store Endpoint ARN and Subscription ID to disk
                NSLog(@"About to call initializeCognitoSync");
                [[AWSClientHelper sharedInstance] initializeCognitoSync];

            }
            return nil;
        }];
    }
}

- (void)showConfirmationMessage{
    UIWindow *mainWindow = [[UIApplication sharedApplication] keyWindow];
    [mainWindow addSubview:self.snsConfirmationMsg];
    self.snsConfirmationMsg.hidden = NO;
    [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(hideConfirmationMessage) userInfo:nil repeats:NO];
}

- (void)hideConfirmationMessage{
    self.snsConfirmationMsg.hidden = YES;
}

- (void) doLoad
{
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        // Instead of sleeping, I do a webrequest here.
        [NSThread sleepForTimeInterval: 5];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.listTableView reloadData];
        });
    });
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.listTableView deselectRowAtIndexPath:self.listTableView.indexPathsForSelectedRows animated:YES];
    [self.listTableView setContentOffset:CGPointZero animated:YES];
}

#pragma mark bottom TableView methods

- (AWSTask *)refreshList:(BOOL)startFromBeginning {
    NSLog(@"refreshing");
        AWSDynamoDBObjectMapper *dynamoDBObjectMapper = [AWSDynamoDBObjectMapper defaultDynamoDBObjectMapper];
        AWSDynamoDBScanExpression *scanExpression = [AWSDynamoDBScanExpression new];
        scanExpression.limit = @20;
    
    return [[dynamoDBObjectMapper scan:[DDBTableRow class] expression:scanExpression] continueWithBlock:^id(AWSTask *task) {
            if (task.error){
                NSLog(@"Error: %@",task.error);
            }
            if (task.exception) {
                NSLog(@"Exception: %@",task.exception);
            }
            if (task.result){
                AWSDynamoDBPaginatedOutput *resultPage = task.result;
                _tableRows = [[NSMutableArray alloc]init];
                for (DDBTableRow *row in resultPage.items) {
//                    NSLog(@"UUID: %@ \nName: %@, \nRSSI: %@",row.UUID, row.name, row.rssi);
                    [self.tableRows addObject:row];
                }
            }
            //Force UI update using GCD while we're not on the main thread
        /*    dispatch_async(dispatch_get_main_queue(),^{
                [self.listTableView reloadData];
            });*/
            [self.listTableView setContentOffset:CGPointZero animated:YES]; //Scroll to top
            return nil;
        }];
    return nil;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.tableRows count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    DDBTableRow *item = self.tableRows[indexPath.row];
    //Setup values for each detected Edison pairing partner in DDB by looking at label tags
    UILabel *partnerEdisonType = (UILabel *)[cell viewWithTag:100];
    UILabel *partnerEdisonUUID = (UILabel *)[cell viewWithTag:99];
    UILabel *partnerEdisonIPAddress = (UILabel *)[cell viewWithTag:98];
    UILabel *partnerEdisonDistance = (UILabel *)[cell viewWithTag:97];
    UILabel *partnerEdisonRSSI = (UILabel *)[cell viewWithTag:96];
    UILabel *partnerEdisonUpdateTime = (UILabel *)[cell viewWithTag:95];
    
    partnerEdisonType.text = [NSString stringWithFormat:@"%@",[self getApplianceName:item.ApplianceType]];
    partnerEdisonUUID.text = [NSString stringWithFormat:@"%@",item.UUID];
    partnerEdisonIPAddress.text = [NSString stringWithFormat:@"%@",item.Name];
    partnerEdisonDistance.text = [NSString stringWithFormat:@"%@",item.Distance];
    partnerEdisonRSSI.text = [NSString stringWithFormat:@"%@",item.RSSI];
    partnerEdisonUpdateTime.text = [NSString stringWithFormat:@"%@",[self getTimeAgo:item.DateUpdated]];
    
    //Setup pairing link to call pairingRequest: or controlPanelLoad as appropriate
    UIButton *pairingButton = (UIButton *)[cell viewWithTag:75];
    UIButton *controlPanelButton = (UIButton *)[cell viewWithTag:50];
    
    //Check if prior pairing exists
    if ([[prefs objectForKey:partnerEdisonUUID.text] isEqual:@"paired"]) {
        NSMutableString *pairedText = [NSMutableString string];
        [pairedText appendString:partnerEdisonType.text];
        [pairedText appendString:@" <PAIRED>"];
        partnerEdisonType.text = pairedText;
        [pairingButton setImage:[UIImage imageNamed:@"link_hi.png"] forState:UIControlStateNormal];
    }
    
    //Pass through ApplianceType as tag to trigger proper Storyboard Scene in -controlPanelSegue:
    controlPanelButton.tag = [item.ApplianceType integerValue];
    [pairingButton addTarget:self action:@selector(pairingCommand:) forControlEvents:UIControlEventTouchUpInside];
    [controlPanelButton addTarget:self action:@selector(controlPanelSegue:) forControlEvents:UIControlEventTouchUpInside];
    
    //Update images for appliance type and signal strength
    UIImageView *edisonImage = (UIImageView *)[cell viewWithTag:25];
    UIImageView *signalStrength = (UIImageView *)[cell viewWithTag:26];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [edisonImage setImage:[UIImage imageNamed:[self getApplianceImage:item.ApplianceType]]];
        float imageStrengthAsFloat = [item.Distance floatValue];
        [signalStrength setImage:[UIImage imageNamed:[self getSignalStrengthImage:imageStrengthAsFloat]]];
    });
    
    if (indexPath.row == [self.tableRows count] - 1 && !self.doneLoading) {
        [self refreshList:NO];
    }
    return cell;
}

- (NSString *) getTimeAgo: (NSNumber*)javaTime{
    long long time = [javaTime longLongValue];
    if (time < 1000000000000L) {
        time *= 1000;
    }
    
    /*The Java representation in DDB is stored as milliseconds since 1970 so we must convert -timeIntervalSince1970 from seconds to milliseconds first*/
    NSDate *now = [NSDate date];
    NSTimeInterval sinceEpoch = [now timeIntervalSince1970];
    long long msec = (long long)(sinceEpoch*1000);
    NSNumber *nowJava = [NSNumber numberWithLongLong:msec];

    if ((time > [nowJava longLongValue]) || (time <= 0)) {
        return @"Just now";
    }
    
    NSMutableString *returnString = [NSMutableString string];
    long long diff = ([nowJava longLongValue] - time);
    if (diff<MINUTE_MILLIS) {
        return @"Just now";
    }else if (diff < 2 * MINUTE_MILLIS){
        return @"A minute ago";
    }else if (diff < 50 * MINUTE_MILLIS){
        NSString *minAgo = [NSString stringWithFormat:@"%lld",diff/MINUTE_MILLIS];
        [returnString appendString:minAgo];
        [returnString appendString:@" minutes ago"];
        return returnString;
    }else if (diff< 90 * MINUTE_MILLIS){
        return @"an hour ago";
    }else if (diff < 24 * HOUR_MILLIS){
        NSString *minAgo = [NSString stringWithFormat:@"%lld",diff/HOUR_MILLIS];
        [returnString appendString:minAgo];
        [returnString appendString:@" hours ago"];
        return returnString;
    }else if (diff < 48 * HOUR_MILLIS){
        return @"yesterday";
    }else{
        NSString *minAgo = [NSString stringWithFormat:@"%lld",diff/DAY_MILLIS];
        [returnString appendString:minAgo];
        [returnString appendString:@" days ago"];
        return returnString;
    }
}

- (NSString *)getApplianceName: (NSString *)applianceTypeNum{
    /*
     APPLIANCE_TYPE_UNKNOWN	 : 0,
     APPLIANCE_TYPE_TOASTER   : 1,
     APPLIANCE_TYPE_MICROWAVE : 2,
     APPLIANCE_TYPE_ESPRESSO  : 3,
     APPLIANCE_TYPE_BLENDER   : 4,
     APPLIANCE_TYPE_KETTLE	 : 5,
     */
    if ([applianceTypeNum isEqual:nil]) {
        return @"Invalid";
    }
    if ([applianceTypeNum isEqual:@"1"]) {
        return @"Toaster";
    }else if ([applianceTypeNum isEqual:@"2"]){
        return @"Microwave";
    }else if ([applianceTypeNum isEqual:@"3"]){
        return @"Espresso";
    }else if ([applianceTypeNum isEqual:@"4"]){
        return @"Blender";
    }else if ([applianceTypeNum isEqual:@"5"]){
        return @"Kettle";
    }else{
        return @"NoID";
    }
}

- (NSString *)getApplianceImage: (NSString *)applianceTypeNum{
    if ([applianceTypeNum isEqual:nil]) {
        return @"aws_icon.png";
    }
    if ([applianceTypeNum isEqual:@"1"]) {
        return @"toaster.png";
    }else if ([applianceTypeNum isEqual:@"2"]){
        return @"microwave.png";
    }else if ([applianceTypeNum isEqual:@"3"]){
        return @"espresso.png";
    }else if ([applianceTypeNum isEqual:@"4"]){
        return @"blender.png";
    }else if ([applianceTypeNum isEqual:@"5"]){
        return @"kettle.png";
    }else{
        return @"aws_icon.png";
    }
}

- (NSString *)getSignalStrengthImage: (float)distance{
    if (distance <= 1.0f) {
        return @"signal_strength_5.png";
    }else if (distance <= 1.5f){
        return @"signal_strength_4.png";
    }else if (distance <= 1.5f){
        return @"signal_strength_3.png";
    }else if (distance <= 1.5f){
        return @"signal_strength_2.png";
    }else{
        return @"signal_strength_1.png";
    }
}

#pragma mark Pairing and Control Panel actions

- (IBAction)pairingCommand:(id)sender {
    AWSSQS *sqs = [AWSSQS defaultSQS];
    AWSSQSSendMessageRequest *messageRequest = [[AWSSQSSendMessageRequest alloc] init];
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    [messageRequest setQueueUrl:[prefs objectForKey:@"sqsUrlToEdison"]];
    
    CommandPacket *cmdPacket = [[CommandPacket alloc] init];

    /*In order to send the correct information to SQS via a CommandPacket we need to grab the IP Address and UUID from the cell that Pair has been clicked. To do this we find the row and call cellForRowAtIndexPath to get a reference to the cell and then grab the values via their assigned tags in Interface Builder*/
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.listTableView];
    NSIndexPath *indexPath = [self.listTableView indexPathForRowAtPoint:buttonPosition];

    UITableViewCell *cell = [[UITableViewCell alloc]init];
    cell =  [self.listTableView cellForRowAtIndexPath:indexPath];
    UILabel *partnerEdisonName = (UILabel *)[cell viewWithTag:100];
    UILabel *partnerEdisonUUID = (UILabel *)[cell viewWithTag:99];
    UILabel *partnerEdisonIPAddress = (UILabel *)[cell viewWithTag:98];
    UIButton *partnerEdisonPairBtn = (UIButton *)[cell viewWithTag:75];
    
    NSLog(@"The partner IP for pairing is: %@",partnerEdisonIPAddress.text);
    NSLog(@"The partner UUID for pairing is: %@",partnerEdisonUUID.text);

    NSDictionary *packet = [cmdPacket commandPacket:2
                                                   :partnerEdisonIPAddress.text
                                                   :partnerEdisonUUID.text
                                                   :@"4"];
    
    //Convert the command to a JSON string which is sent to SQS to be read by IoT device
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:packet
                                                       options:0
                                                         error:&error];
    
    NSString *JSONString = [[NSString alloc] initWithBytes:[jsonData bytes] length:[jsonData length] encoding:NSUTF8StringEncoding];
    NSLog(@"JSON CommandPacket: %@",JSONString);

    NSMutableString *pairingMessage = [[NSMutableString alloc]initWithString:@"Initiating pair with "];
    [pairingMessage appendString:partnerEdisonIPAddress.text];
    [pairingMessage appendString:@"\nPlease Wait..."];
    NSLog(@"pairingMessage: %@",pairingMessage);
    
    //TODO:Refactor this as a separate method
    UIAlertView *alert = alert = [[UIAlertView alloc] initWithTitle:pairingMessage message:nil delegate:self cancelButtonTitle:nil otherButtonTitles: nil];
    //Dispatch alert on main thread to avoid delays
    [alert performSelectorOnMainThread:@selector(show) withObject:nil waitUntilDone:YES];
    
    UIActivityIndicatorView *indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    
    // Adjust the indicator so it is up a few pixels from the bottom of the alert
    indicator.center = CGPointMake(alert.bounds.size.width / 2, alert.bounds.size.height - 50);
    [indicator startAnimating];
    [alert addSubview:indicator];
    
    //Send pairing command to SQS
    [messageRequest setMessageBody:JSONString];
         [[sqs sendMessage:messageRequest] continueWithBlock:^id(AWSTask *task) {
        NSLog(@"Sent AWSTask SQS");
        if(task.error){
            NSLog(@"SQS Error: %@",task.error);
            [alert dismissWithClickedButtonIndex:0 animated:YES];
        }else{
            NSLog(@"SQS Result: %@",task.result);
                [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(pairingComplete) name:@"pairingComplete" object:nil];
            
            int sleep = 1;
            while (sleep<30) {              //Wait for a pairing response from SNS notification for 30 seconds
                if ([[prefs objectForKey:@"paired"]  isEqual: @"true"]) {
                    sleep=30;
                }
                    NSLog(@"Pairing for %d seconds...", sleep);
                    sleep++;
                    [NSThread sleepForTimeInterval:1.0f];
            }

            if (![[prefs objectForKey:@"paired"]  isEqual: @"true"]) {
                [alert dismissWithClickedButtonIndex:0 animated:YES];
                //TODO:Refactor this as a separate method
                UIAlertView *alert = alert = [[UIAlertView alloc] initWithTitle:@"Pairing failed\nPlease ensure devices are running appliance-manager.js and SNS is configured." message:nil delegate:self cancelButtonTitle:nil otherButtonTitles: nil];
                //Dispatch alert on main thread to avoid delays
                [alert performSelectorOnMainThread:@selector(show) withObject:nil waitUntilDone:YES];
                
                UIActivityIndicatorView *indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
                
                // Adjust the indicator so it is up a few pixels from the bottom of the alert
                indicator.center = CGPointMake(alert.bounds.size.width / 2, alert.bounds.size.height - 50);
                [indicator startAnimating];
                [alert addSubview:indicator];
                [NSThread sleepForTimeInterval:5.f];
                [alert dismissWithClickedButtonIndex:0 animated:YES];
            }else{
                [alert dismissWithClickedButtonIndex:0 animated:YES];
                //Change image on main thread for UIKit update to be immediate
                NSMutableString *pairedText = [NSMutableString string];
                [pairedText appendString:partnerEdisonName.text];
                [pairedText appendString:@" <PAIRED>"];
                dispatch_async(dispatch_get_main_queue(), ^{
                    [partnerEdisonPairBtn setImage:[UIImage imageNamed:@"link_hi.png"] forState:UIControlStateNormal];
                    partnerEdisonName.text = pairedText;
                });
                //Update prefs for historical tracking
                [prefs setValue:@"paired" forKey:partnerEdisonUUID.text];
                [prefs setValue:@"pending" forKey:@"paired"];
                [prefs synchronize];
            }
        }
        return task.result;
    }];
}

- (void) pairingComplete{
    NSLog(@"setting pairing values in -pairingComplete:");
    
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    [prefs setValue:@"true" forKey:@"paired"];
    [prefs synchronize];
    
    //Pairing over remove listening
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:@"pairingComplete"
                                                  object:nil];

}

- (void) alertMessages: (NSString *)message{
    
}

- (IBAction)controlPanelSegue:(id)sender {
    UIButton *button = (UIButton*)sender;
    if (![[self getApplianceName:[NSString stringWithFormat:@"%d",button.tag]] isEqual: @"NoID"]) {
        NSString * storyboardName = @"Main";
        NSString * viewControllerID = [self getApplianceName:[NSString stringWithFormat:@"%d",button.tag]];
        UIStoryboard * storyboard = [UIStoryboard storyboardWithName:storyboardName bundle:nil];
        MicrowaveView * controller = (MicrowaveView *)[storyboard instantiateViewControllerWithIdentifier:viewControllerID];
        [self presentViewController:controller animated:YES completion:nil];
    } else {
        UIAlertView *alert = alert = [[UIAlertView alloc] initWithTitle:@"Invalid Appliance Type\nPlease check your DynamoDB table and Lambda Functions." message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
        //Dispatch alert on main thread to avoid delays
        [alert performSelectorOnMainThread:@selector(show) withObject:nil waitUntilDone:YES];
        
        UIActivityIndicatorView *indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
        
        // Adjust the indicator so it is up a few pixels from the bottom of the alert
        indicator.center = CGPointMake(alert.bounds.size.width / 2, alert.bounds.size.height - 50);
        [indicator startAnimating];
        [alert addSubview:indicator];
    }
}


#pragma mark CognitoSync notification
#pragma warning this probably should go into the control panels

- (void)didReceivePushSync:(NSNotification*)notification
{
    NSDictionary * data = [(NSDictionary *)[notification object] objectForKey:@"data"];
    NSString * identityId = [data objectForKey:@"identityId"];
    NSString * datasetName = [data objectForKey:@"datasetName"];
    
    AWSCognito *syncClient = [AWSCognito defaultCognito];
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
    AWSCognitoDataset *dataset = [syncClient openOrCreateDataset:[preferences objectForKey:@"cognitoDatasetName"]];
    if([dataset.name isEqualToString:datasetName] && [[AWSClientHelper sharedInstance].cognitoID isEqualToString:identityId]){
        [[dataset synchronize] continueWithBlock:^id(AWSTask *task) {
            if(!task.error){
                NSLog(@"Successfully synced dataset");
            }
            return nil;
        }];
    }
}

@end

