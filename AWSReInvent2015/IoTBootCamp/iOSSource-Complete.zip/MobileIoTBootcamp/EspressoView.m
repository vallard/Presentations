//
//  EspressoView.m
//  MobileIoTBootcamp
//
//  Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License").
//  You may not use this file except in compliance with the License.
//  A copy of the License is located at
//
//  http://aws.amazon.com/apache2.0
//
//  or in the "license" file accompanying this file. This file is distributed
//  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
//  express or implied. See the License for the specific language governing
//  permissions and limitations under the License.
//
//  This source code forms part of the codebase for the re:Invent 2015 Bootcamp - "Creating applications for Mobile and IoT"
//
//  Created by Richard Threlkeld on 7/20/15.
//

#import "EspressoView.h"
#import "AWSCore.h"
#import "AWSCognito.h"
#import <AWSMobileAnalytics/AWSMobileAnalytics.h>
#import "AWSClientHelper.h"

const float KEEPHOTTIME_MIN = 10;
const float KEEPHOT_MAX = 60;
const float TEMPERATURE_MIN = 100;
const float TEMPERATURE_MAX = 150;

@implementation EspressoView

@synthesize espressoTempKey;
@synthesize keepHotTimeKey;

- (void)viewDidLoad{
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(CognitoSyncUpdate) name:@"CognitoSyncUpdate" object:nil];
    
    NSMutableString *waterTemp = [NSMutableString stringWithFormat:
                                  [NSBundle mainBundle].bundleIdentifier];
    [waterTemp appendString:@".waterTemp"];
    
    NSMutableString *Duration = [NSMutableString stringWithFormat:
                                     [NSBundle mainBundle].bundleIdentifier];
    [Duration appendString:@".KeepHot"];
    
    espressoTempKey = [NSString stringWithString:waterTemp];
    keepHotTimeKey = [NSString stringWithString:Duration];
    
    AWSCognito *syncClient = [AWSCognito defaultCognito];
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
    AWSCognitoDataset *dataset = [syncClient openOrCreateDataset:
                                  [preferences objectForKey:@"uniqueDatasetName"]];
    [dataset synchronize];
    
    self.espressoTemp.maximumValue = (int)(TEMPERATURE_MAX - TEMPERATURE_MIN);
    self.keepHotTime.maximumValue = (int)(KEEPHOT_MAX - KEEPHOTTIME_MIN);
    
    self.espressoTemp.value = [self calcTempValueSliderFromCognito:
                            [dataset stringForKey:espressoTempKey].intValue];
    
    self.keepHotTime.value = [self calcTimeSliderFromCognito:
                               [dataset stringForKey:keepHotTimeKey].intValue];
    
    self.tempSettingLabel.text = [NSString stringWithFormat:@"%d", (int)[self calcTempValueSliderFromCognito:[dataset stringForKey:espressoTempKey].intValue]];
    
    self.timeSettingLabel.text = [NSString stringWithFormat:@"%d", (int)[self calcTimeSliderFromCognito:[dataset stringForKey:keepHotTimeKey].intValue]];
}

- (void) viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:NO];
}

- (int) calcTimeSliderProgress:(float)progress{
    return (int)(KEEPHOTTIME_MIN + progress);
}

- (float) calcTimeSliderFromCognito:(int)time{
    return (time - KEEPHOTTIME_MIN);
}

- (int) calcTempValueSliderProgress:(float)progress{
    return (int)(TEMPERATURE_MIN + progress);
}

- (float) calcTempValueSliderFromCognito:(int)time{
    return (time - TEMPERATURE_MIN);
}

-(void)CognitoSyncUpdate
{
    AWSCognito *syncClient = [AWSCognito defaultCognito];
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
    AWSCognitoDataset *dataset = [syncClient openOrCreateDataset:[preferences objectForKey:@"uniqueDatasetName"]];
    [dataset synchronize];
    
    self.espressoTemp.value = [dataset stringForKey:espressoTempKey].floatValue;
    self.keepHotTime.value = [dataset stringForKey:keepHotTimeKey].floatValue;
    self.tempSettingLabel.text = [NSString stringWithFormat:@"%d",[dataset stringForKey:espressoTempKey].intValue];
    self.timeSettingLabel.text = [NSString stringWithFormat:@"%d",[dataset stringForKey:keepHotTimeKey].intValue];
}

- (IBAction)returnToDeviceScreen:(id)sender {
    [self.presentingViewController dismissViewControllerAnimated:YES completion:NULL];
}

- (IBAction)controlPanelValueChanged:(id)sender{
    NSLog(@"Setting local dataset values \nwaterTemp: %d\nDuration: %d",(int)self.espressoTemp.value,(int)self.keepHotTime.value);
    AWSCognito *syncClient = [AWSCognito defaultCognito];
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
    AWSCognitoDataset *dataset = [syncClient openOrCreateDataset:[preferences objectForKey:@"uniqueDatasetName"]];
    
    [dataset setString:[NSString stringWithFormat:@"%d",(int)self.espressoTemp.value] forKey:espressoTempKey];
    [dataset setString:[NSString stringWithFormat:@"%d",(int)self.keepHotTime.value] forKey:keepHotTimeKey];
    self.tempSettingLabel.text = [NSString stringWithFormat:@"%d",(int)self.espressoTemp.value];
    self.timeSettingLabel.text = [NSString stringWithFormat:@"%d",(int)self.keepHotTime.value];
}

- (NSString*)getPanelNameForAnalytics{
    return @"EspressoControlPanel";
}

- (IBAction)updateButton:(id)sender {
    AWSCognito *syncClient = [AWSCognito defaultCognito];
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
	
	//Sync Cognito Dataset
	AWSCognitoDataset *dataset = [syncClient openOrCreateDataset:[preferences objectForKey:@"uniqueDatasetName"]];
	NSLog(@"Synchronizing dataset with Cognito");
	[dataset synchronize];
	
	//Send data to Mobile Analytics
	AWSMobileAnalytics *analytics = [[AWSClientHelper sharedInstance] analytics:[preferences objectForKey:@"mobileanalyticsAppId"]];
	id<AWSMobileAnalyticsEventClient> eventClient = analytics.eventClient;
	id<AWSMobileAnalyticsEvent> customEvent = [eventClient createEventWithEventType:[self getPanelNameForAnalytics]];
	
	[customEvent addMetric:[NSNumber numberWithFloat:
							[self calcTempValueSliderProgress:
							 self.espressoTemp.value]] forKey:@"MaxTemp"];
	
	[customEvent addMetric:[NSNumber numberWithFloat:
							[self calcTimeSliderProgress:
							 self.keepHotTime.value]] forKey:@"Time"];
	
	[eventClient recordEvent:customEvent];
	NSLog(@"Sending temperature and KeepHot events to Moble Analytics");
	[eventClient submitEvents];

}


@end
