//
//  ChatViewController.h
//  MobileIoTBootcamp
//
//  Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License").
//  You may not use this file except in compliance with the License.
//  A copy of the License is located at
//
//  http://aws.amazon.com/apache2.0
//
//  or in the "license" file accompanying this file. This file is distributed
//  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
//  express or implied. See the License for the specific language governing
//  permissions and limitations under the License.
//
//  This source code forms part of the codebase for the re:Invent 2015 Bootcamp - "Creating applications for Mobile and IoT"
//
//  Created by Richard Threlkeld on 7/20/15.
//
/*Code based on chat example from Ray Wenderlich: http://www.raywenderlich.com/32963/apple-push-notification-services-in-ios-6-tutorial-part-2*/

#include "AppDelegate.h"
#import "CloudMessage.h"
#import "CommandPacket.h"

@class DataModel;

// The main screen of the app. It shows the history of all messages that
// this user has sent and received.

@protocol MessageDataDelegate <NSObject>

@optional
- (void) sentMessageSuccessfully:(BOOL)success;
@end

@interface ChatViewController : UIViewController<ComposeDelegate, UITableViewDataSource, UITableViewDelegate> {
    id <MessageDataDelegate> delegate;
}

@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;

@property (weak, nonatomic) IBOutlet UITableView *chatTableView;

@property (nonatomic, strong, readonly) DataModel* dataModel;

@property (weak, nonatomic) IBOutlet UITextField *inputTextField;

@property (nonatomic,strong) id delegate;

- (void) sendMessage:(NSString *)messageText sentByUser:(BOOL)sentUser;

@end
