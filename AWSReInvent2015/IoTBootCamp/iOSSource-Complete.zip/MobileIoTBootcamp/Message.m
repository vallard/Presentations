//
//  Message.m
//  MobileIoTBootcamp
//
//  Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License").
//  You may not use this file except in compliance with the License.
//  A copy of the License is located at
//
//  http://aws.amazon.com/apache2.0
//
//  or in the "license" file accompanying this file. This file is distributed
//  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
//  express or implied. See the License for the specific language governing
//  permissions and limitations under the License.
//
//  This source code forms part of the codebase for the re:Invent 2015 Bootcamp - "Creating applications for Mobile and IoT"
//
//  Created by Richard Threlkeld on 7/20/15.
//
/*Code based on chat example from Ray Wenderlich: http://www.raywenderlich.com/32963/apple-push-notification-services-in-ios-6-tutorial-part-2*/

#import "Message.h"

static NSString* const SenderNameKey = @"SenderName";
static NSString* const DateKey = @"Date";
static NSString* const TextKey = @"Text";

@implementation Message

- (id)initWithCoder:(NSCoder*)decoder
{
	if ((self = [super init]))
	{
		self.senderName = [decoder decodeObjectForKey:SenderNameKey];
		self.date = [decoder decodeObjectForKey:DateKey];
		self.text = [decoder decodeObjectForKey:TextKey];
	}
	return self;
}

- (void)encodeWithCoder:(NSCoder*)encoder
{
	[encoder encodeObject:self.senderName forKey:SenderNameKey];
	[encoder encodeObject:self.date forKey:DateKey];
	[encoder encodeObject:self.text forKey:TextKey];
}

- (BOOL)isSentByUser
{
	return self.senderName == nil;
}
@end
