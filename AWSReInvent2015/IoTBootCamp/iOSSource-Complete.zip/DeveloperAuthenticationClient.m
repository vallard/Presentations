//
//  DeveloperAuthenticationClient.h
//  MobileIoTBootcamp
//
//  Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License").
//  You may not use this file except in compliance with the License.
//  A copy of the License is located at
//
//  http://aws.amazon.com/apache2.0
//
//  or in the "license" file accompanying this file. This file is distributed
//  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
//  express or implied. See the License for the specific language governing
//  permissions and limitations under the License.
//
//  This source code forms part of the codebase for the re:Invent 2015 Bootcamp - "Creating applications for Mobile and IoT"
//
//  Created by Richard Threlkeld on 7/20/15.
//
//  NOTE: This code is not to be considered production-ready since it is a simplified implementation of Developer Authentication through Cognito, for instructional purposes only.
// For a full implementation, see http://mobile.awsblog.com/post/Tx3E3NJURV1LNV1/Integrating-Amazon-Cognito-using-developer-authenticated-identities-An-end-to-en


#import "DeveloperAuthenticationClient.h"
#import <AWSCore/AWSCore.h>
#import "GetTokenRequestModel.h"
#import "GetTokenResponseModel.h"
#import "AuthenticationAPIClient.h"
#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import <FBSDKCoreKit/FBSDKCoreKit.h>

NSString *const ProviderPlaceHolder = @"foobar.com";
NSString *const DeveloperAuthenticationClientDomain = @"com.amazonaws.service.cognitoidentity.DeveloperAuthenticatedIdentityProvider";
NSString *const UidKey = @"uid";

@interface DeveloperAuthenticationResponse()

@property (nonatomic, strong) NSString *identityId;
@property (nonatomic, strong) NSString *identityPoolId;
@property (nonatomic, strong) NSString *token;

@end

@implementation DeveloperAuthenticationResponse
@end

@interface DeveloperAuthenticationClient()
@property (nonatomic, strong) NSString *identityPoolId;
@property (nonatomic, strong) NSString *identityId;
@property (nonatomic, strong) NSString *token;

// used for internal encryption
@property (nonatomic, strong) NSString *uid;
@property (nonatomic, strong) NSString *key;


@end

@implementation DeveloperAuthenticationClient

+ (instancetype)identityProviderWithAppname:(NSString *)appname endpoint:(NSString *)endpoint {
    return [[DeveloperAuthenticationClient alloc] initWithAppname:appname endpoint:endpoint];
}

- (instancetype)initWithAppname:(NSString *)appname endpoint:(NSString *)endpoint {
    if (self = [super init]) {
        self.appname  = appname;
        self.endpoint = endpoint;
    }
    
    return self;
}

- (BOOL)isAuthenticated {
    return self.key != nil;
}

// Returns 1 if login successful and 0 if not
- (AWSTask *)login:(NSString *)username password:(NSString *)password {
    // If the key is already set, the login already succeeeded
    if (self.key) {
        return [AWSTask taskWithResult:self.key];
    }
    NSLog(@"about to call");
    return [[AWSTask taskWithResult:nil] continueWithBlock:^id(AWSTask *task) {
        //Login with API Gateway using Lambda function.
        //This basic example just checks for username=username and password=password. NOT a production example.
        AuthenticationAPIClient *client = [AuthenticationAPIClient defaultClient];
        
        LoginRequestModel *loginRequest = [LoginRequestModel new];
        [loginRequest setUsername:username];
        [loginRequest setPassword:password];
        
        [[client loginPost:loginRequest] continueWithBlock:^id(AWSTask *task) {
            if (task.error) {
                NSLog(@"Error authenticating against IdP");
                return task.error;
            }
            if (task.result){   //Successfully hit Lambda via API Gateway
                NSLog(@"IdP login succeeded: %@", [task.result succeeded]);
                NSLog(@"IdP login message: %@", [task.result message]);
                /*If login returns a success message from the Lambda function via API Gateway 
                  then continue and link this login with the Cognito ID*/
                if ([[task.result succeeded]  isEqualToNumber:[NSNumber numberWithInt:1]]){
                    AWSClientHelper *clientHelper = [AWSClientHelper sharedInstance];
                    NSDictionary *idpLogon = @{@"idp.custom.bootcamp2015":username};
                    [clientHelper linkLoginsToAuthenticate:idpLogon];
                }else{
                    return task.error;
                }
            }
            return [AWSTask taskWithResult:nil];
        }];
        return [AWSTask taskWithResult:nil];
    }];
    
}

- (void)logout {
    self.key = nil;
    self.uid = nil;
}

// call gettoken and set our values from returned result
- (AWSTask *)getToken:(NSString *)identityId logins:(NSDictionary *)logins {
    NSLog(@"Inside -getToken");
    
    // make sure we've authenticated
    if (![self isAuthenticated]) {
        return [AWSTask taskWithError:[NSError errorWithDomain:DeveloperAuthenticationClientDomain
                                                         code:DeveloperAuthenticationClientLoginError
                                                     userInfo:nil]];
    }
    
    return [[AWSTask taskWithResult:nil] continueWithBlock:^id(AWSTask *task) {
        
        AuthenticationAPIClient *client = [AuthenticationAPIClient defaultClient];
        GetTokenRequestModel *requestModel = [GetTokenRequestModel new];
        
        NSLog(@" FBToken: %@",[FBSDKAccessToken currentAccessToken].tokenString);
        if ([FBSDKAccessToken currentAccessToken].tokenString){
            [requestModel setBootcampAuth:@"graph.facebook.com"];
        }
        
        [requestModel setBootcampAuth:@"idp.custom.bootcamp2015"];
        AWSClientHelper *sharedInstance = [AWSClientHelper sharedInstance];
        [requestModel setCognitoId:[sharedInstance cognitoID]];
        
        [[client gettokenPost:requestModel] continueWithBlock:^id(AWSTask *task) {
            if (task.error){
                NSLog(@"Error: %@",task.error);
                return nil;
            }
            if (task.result){
                GetTokenResponseModel *responseModel = task.result;
                NSLog(@"response: %@",responseModel);
                return responseModel;
            }
            return nil;
        }];
        return nil;
    }];
}

@end
