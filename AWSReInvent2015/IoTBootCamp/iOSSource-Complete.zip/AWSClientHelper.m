//
//  AWSClientHelper.m
//  MobileIoTBootcamp
//
//  Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License").
//  You may not use this file except in compliance with the License.
//  A copy of the License is located at
//
//  http://aws.amazon.com/apache2.0
//
//  or in the "license" file accompanying this file. This file is distributed
//  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
//  express or implied. See the License for the specific language governing
//  permissions and limitations under the License.
//
//  This source code forms part of the codebase for the re:Invent 2015 Bootcamp - "Creating applications for Mobile and IoT"
//
//  Created by Richard Threlkeld on 7/20/15.
//

#import "AWSClientHelper.h"
#import <AWSCognito/AWSCognito.h>
#import <AWSTask.h>
#import "DeveloperAuthenticatedIdentityProvider.h"
#import "DeveloperAuthenticationClient.h"

#define FB_PROVIDER @"Facebook"
#define IDP @"DeveloperAuth"

@interface AWSClientHelper()

@property (nonatomic,strong) AWSCognitoCredentialsProvider *credentialsProvider;
@property (nonatomic, strong) DeveloperAuthenticationClient *devAuthClient;

@end


@implementation AWSClientHelper

@synthesize cognitoID;
@synthesize cognitoPool;

//Setup Singleton
+ (AWSClientHelper *)sharedInstance{
    static AWSClientHelper *sharedInstance = nil;
    static dispatch_once_t onceToken;               //Ensures *sharedInstance only created once by GCD
    
    dispatch_once(&onceToken,^{
        sharedInstance = [AWSClientHelper new];
        sharedInstance.devAuthClient = [[DeveloperAuthenticationClient alloc] init];
    });
    return sharedInstance;
}


- (id)init{
    if(self = [super init]){
        cognitoPool = @"invalidPool";
    }
    return self;
}

- (NSString *)getIdentityId{
    return self.credentialsProvider.identityId;
}

#pragma mark identity initialization and login linking

- (AWSTask *)initializeCognito: (NSDictionary *)logins{
        NSLog(@"\nInside -initializeCognito with cognitoPool: %@",cognitoPool);
        for(id key in logins){
            id value = [logins objectForKey:key];
            NSLog(@"logins value passed to initializeCognito: %@",value);
        }
    
        id<AWSCognitoIdentityProvider> identityProvider = [[DeveloperAuthenticatedIdentityProvider alloc] initWithRegionType:AWSRegionUSEast1
                                                                                                              identityId:nil
                                                                                                          identityPoolId:cognitoPool
                                                                                                                  logins:logins
                                                                                                            providerName:@"idp.custom.bootcamp2015"
                                                                                                              authClient:self.devAuthClient];

        self.credentialsProvider = [[AWSCognitoCredentialsProvider alloc] initWithRegionType:AWSRegionUSEast1
                                                                        identityProvider:identityProvider
                                                                           unauthRoleArn:nil
                                                                             authRoleArn:nil];
    
        AWSServiceConfiguration *configuration = [[AWSServiceConfiguration alloc] initWithRegion:AWSRegionUSEast1
                                                                         credentialsProvider:self.credentialsProvider];
        AWSServiceManager.defaultServiceManager.defaultServiceConfiguration = configuration;
        [self setCognitoID:self.credentialsProvider.identityId];
    
    [self.credentialsProvider refresh];
        
    NSLog(@"self.credentialsProvider.identityId: %@",self.credentialsProvider.identityId);
    NSLog(@"Cognito initialized with IdenityID of: %@",cognitoID);

    return [self.credentialsProvider getIdentityId];
}

- (void) clear{
    self.credentialsProvider.logins = nil;
    [[AWSCognito defaultCognito] wipe];
    [self.credentialsProvider clearKeychain];
    [self.credentialsProvider clearCredentials];
    [self.credentialsProvider refresh];
    self.credentialsProvider = nil;
}

- (void)linkLoginsToAuthenticate:(NSDictionary *)logins{
    NSLog(@"Calling -linkLoginsToAuthenticate");
    AWSTask *task;
    if (self.credentialsProvider == nil) {
        for(id key in logins){
            id value = [logins objectForKey:key];
            NSLog(@"value: %@",value);
        }
        task = [self initializeCognito:logins];
    }
    else {
        NSMutableDictionary *merge = [NSMutableDictionary dictionaryWithDictionary:self.credentialsProvider.logins];
        [merge addEntriesFromDictionary:logins];
        self.credentialsProvider.logins = merge;
        // Force a refresh of credentials to see if we need to merge
        task = [self.credentialsProvider refresh];
    }
}

#pragma mark Cognito Sync methods

- (void)unsubCognitoSync{
    NSLog(@"Attempting to unsubscribe from Cognito Sync");
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
    AWSCognitoDataset *dataset = [[AWSCognito defaultCognito] openOrCreateDataset:[preferences objectForKey:@"uniqueDatasetName"]];
     [[dataset unsubscribe] continueWithBlock:^id(AWSTask *task) {
         NSLog(@"Inside unsubscribe: %@",task.result);
        if (task.error) {
            NSLog(@"Unsubscribe Cognito Sync failed: %@",task.error);
        }else {
            NSLog(@"Unsubscribe Cognito Sync succeeded: %@",task.result);
        }
        return nil;
    }];
    
}


- (void)initializeCognitoSync{
    AWSCognito *syncClient = [AWSCognito defaultCognito];
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
    
    //Register device token: note we use "deviceTokenData" because registerDevice takes an input of NSData not NSString
    NSLog(@"Attempting to register with Cognito Sync");
    [[syncClient registerDevice:[preferences objectForKey:@"deviceTokenData"]] continueWithBlock:^id(AWSTask *task) {
        if (task.error) {
            NSLog(@"Unable to register device for Cognito Sync: %@",task.error);
        }else{
            NSLog(@"Successfully regisered device for Cognito Sync: %@",task.result);
            AWSCognitoDataset *dataset = [[AWSCognito defaultCognito] openOrCreateDataset:[preferences objectForKey:@"uniqueDatasetName"]];

            //Now the device is known to AWS, subscribe to our dataset. We will increment a counter to keep the number of times we've done this, in the Dataset
            NSString *value = [dataset stringForKey:@"InitialisationCounter"];
            if (!value) {
                value = @"0";
            }
            
            int valueAsInteger = [value intValue];
            valueAsInteger++;
            
            [dataset setString:[NSString stringWithFormat:@"%d", valueAsInteger] forKey:@"InitialisationCounter"];
            
            //Now that initial value is present syncronize the dataset and subscribe to Cognito Sync
            [dataset synchronize];
            [[dataset subscribe] continueWithBlock:^id(AWSTask *task) {
                if (task.error) {
                    NSLog(@"Error subscribing to dataset: %@",task.error);
                }else{
                    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
                    [userDefaults setObject:@"Subscribed" forKey: dataset.name];
                    [userDefaults synchronize];
                }
                return nil;
            }];
        }
        return nil;
    }];
}

#pragma mark Mobile Analytics
- (AWSMobileAnalytics *)analytics: (NSString*)applicationId{
    AWSMobileAnalytics *analytics = [AWSMobileAnalytics mobileAnalyticsForAppId:applicationId
                                                                 identityPoolId:self.cognitoPool];
    return analytics;
}


@end








