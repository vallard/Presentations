//
//  ViewController.m
//  MobileIoTBootcamp
//
//  Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License").
//  You may not use this file except in compliance with the License.
//  A copy of the License is located at
//
//  http://aws.amazon.com/apache2.0
//
//  or in the "license" file accompanying this file. This file is distributed
//  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
//  express or implied. See the License for the specific language governing
//  permissions and limitations under the License.
//
//  This source code forms part of the codebase for the re:Invent 2015 Bootcamp - "Creating applications for Mobile and IoT"
//
//  Created by Richard Threlkeld on 7/20/15.
//

#import "ViewController.h"
#include "DeveloperAuthenticationClient.h"
#include "AWSClientHelper.h"
#import <AWSSNS/AWSSNS.h>

@interface ViewController ()

@end

@implementation ViewController

@synthesize tethered;
@synthesize facebookButton;
@synthesize idPButton;
@synthesize tetheredAppliance;


- (void)viewDidLoad {
	[super viewDidLoad];
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];

    if ([preferences objectForKey:@"name"]){
        self.tetheredAppliance.text = [preferences objectForKey:@"name"];
    }else{
        self.tetheredAppliance.text = @"NONE";
    }
    
    AWSClientHelper *clientHelper = [AWSClientHelper sharedInstance];
    
    if ([FBSDKAccessToken currentAccessToken]) {
        NSLog(@"Token is available");
        [self fetchUserInfo];
    } else {
        FBSDKLoginButton *loginView = facebookButton;
        loginView.readPermissions =  @[@"email"];
        //loginView.frame = CGRectMake(100, 150, 100, 40);
        loginView.delegate = self;
        [self.view addSubview:loginView];
    }
    
	//Get values from tether before allowing logon
	NSString *currentKey = @"cognitoIdentityPoolId";
	if ([preferences objectForKey:currentKey] == nil){
		NSLog(@"ERROR: Shared Preferences cannot be found on disk");
	}else{
		NSLog(@"Preferences loaded: %@",[preferences objectForKey:currentKey]);
        [clientHelper setCognitoPool:[preferences objectForKey:currentKey]];
        tethered = YES;
    }
    
    if (tethered != YES){
        facebookButton.enabled = NO;
        idPButton.enabled = NO;
    }
    

}

- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning];
	// Dispose of any resources that can be recreated.
}

#pragma mark Tether SECTION
- (IBAction)tetherAppliance:(id)sender{
        NSString *message = @"Enter the UUID for the Edison you want to pair with or use the Central Web Site and scan the QR code";
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Appliance UUID"
                                                        message:message
                                                       delegate:self
                                              cancelButtonTitle:@"Cancel"
                                              otherButtonTitles:@"Scan QR",@"Ok", nil];
        alert.alertViewStyle = UIAlertViewStylePlainTextInput;
        [alert show];

}

- (void) tetherSuccess{
    self.tethered = YES;
    
    //Cognito Clean-up
    [[AWSClientHelper sharedInstance] clear];
    AWSClientHelper *clientHelperRealloc = [AWSClientHelper sharedInstance];
    NSLog(@"CognitoPool: %@",clientHelperRealloc.cognitoPool);
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
    [clientHelperRealloc setCognitoPool:[preferences objectForKey:@"cognitoIdentityPoolId"]];
    NSLog(@"CognitoPool: %@",clientHelperRealloc.cognitoPool);
    NSLog(@"CognitoID after cleanup: %@",[[AWSClientHelper sharedInstance] getIdentityId]);
    
    //Notify user to re-open application
    NSLog(@"alertVisible: %hhd",self.alertVisible);
    if(!self.alertVisible){
        dispatch_async(dispatch_get_main_queue(), ^{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Tethering is complete\n\nPlease re-open the app to login." message:nil delegate:self cancelButtonTitle:nil otherButtonTitles: nil];
            
            [alert performSelectorOnMainThread:@selector(show) withObject:nil waitUntilDone:YES];
            //[alert show];
            UIActivityIndicatorView *indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
            
            // Adjust the indicator so it is up a few pixels from the bottom of the alert
            indicator.center = CGPointMake(alert.bounds.size.width / 2, alert.bounds.size.height - 50);
            [indicator startAnimating];
            [alert addSubview:indicator];
            self.alertVisible = YES;
            NSLog(@"JUST SET alertVisible: %hhd",self.alertVisible);
        });

        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
            [NSThread sleepForTimeInterval:10.0f];
            exit(0);
        });
    }
}

- (void) previousTetherCleanup{
    NSLog(@"Running previousTetherCleanup:");
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
    
    //Unsubscribe Cognito Dataset subscription
    [[AWSClientHelper sharedInstance] unsubCognitoSync];
    
    //Delete SNS endpoint Cognito Dataset Sync was using
    AWSSNS *sns = [AWSSNS defaultSNS];
    AWSSNSDeleteEndpointInput *cognitoSyncEndpoint = [AWSSNSDeleteEndpointInput new];
    cognitoSyncEndpoint.endpointArn = [preferences objectForKey:@"cognitoSyncEndpointArn"];
    NSLog(@"Attempting to delete %@", cognitoSyncEndpoint.endpointArn);
    [[sns deleteEndpoint:cognitoSyncEndpoint] continueWithBlock:^id(AWSTask *task) {
        if (task.error) {
            NSLog(@"Error deleting endpoint %@",task.error);
        }else{
            NSLog(@"deleteEndpoint returned %@",task.result);
        }
        return nil;
    }];
    
    //Delete SNS endpoint used by other application functions
    AWSSNSDeleteEndpointInput *existingEndpoint = [AWSSNSDeleteEndpointInput new];
    existingEndpoint.endpointArn = [preferences objectForKey:@"endpointArn"];
    NSLog(@"Attempting to delete %@", existingEndpoint.endpointArn);
    [[sns deleteEndpoint:existingEndpoint] continueWithBlock:^id(AWSTask *task) {
        if (task.error){
            NSLog(@"Error deleting endpoint %@",task.error);
        } else {
            NSLog(@"deleteEndpoint returned %@",task.result);
        }
        return nil;
    }];
    
    //Delete SNS Topic subscription
    AWSSNSUnsubscribeInput *existingSubscription = [AWSSNSUnsubscribeInput new];
    existingSubscription.subscriptionArn = [preferences objectForKey:@"snsSubscriptionId"];
    NSLog(@"snsArnTopicToMobile: %@",[preferences objectForKey:@"snsSubscriptionId"]);
    NSLog(@"Attempting to delete %@", existingSubscription.subscriptionArn);
    [[sns unsubscribe:existingSubscription] continueWithBlock:^id(AWSTask *task) {
        if(task.error){
            NSLog(@"Error deleting subscription: %@",task.error);
        }else{
            NSLog(@"Delete subscription returned: %@",task.result);
        }
        return nil;
    }];
}

#pragma mark IdP SECTION
- (IBAction)loginWithIdP:(id)sender {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Custom IdP Login"
                                                    message:@"Enter a valid Username & Password"
                                                   delegate:self
                                          cancelButtonTitle:@"Cancel"
                                          otherButtonTitles:nil];
    alert.alertViewStyle = UIAlertViewStyleLoginAndPasswordInput;
    [alert addButtonWithTitle:@"Login"];
    [alert show];
    [alert textFieldAtIndex:0].text = @"username";      //For easier testing, might remove later
    [alert textFieldAtIndex:1].text = @"password";
}

#pragma mark UIAlertView delegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
	
    NSString *buttonTitle = [alertView buttonTitleAtIndex:buttonIndex];
	
    if ([buttonTitle isEqualToString:@"Scan QR"]) {                                                                 //First two checks called from -tetherAppliance
		NSLog(@"Entered QR code scanning call here");
		AMScanViewController *scanViewController = [[AMScanViewController alloc] init];
		[self.navigationController pushViewController:scanViewController
                                             animated:YES];
    }else if ([buttonTitle isEqualToString:@"Ok"]){
        if (![[[alertView textFieldAtIndex:0] text]  isEqual: @""]){
            NSLog(@"Entered %@", [[alertView textFieldAtIndex:0]text]);
                NSString *url = [NSString stringWithFormat:@"%@%@%@",centralURL,@"appliance/",[[alertView textFieldAtIndex:0] text]];
            NSLog(@"url: %@",url);
                NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
                __unused NSURLConnection *fetchConn = [[NSURLConnection alloc]initWithRequest:request delegate:self];
        }
    }else if ([buttonTitle isEqualToString:@"Login"]){                                                              //Called only from -loginWithIdP
        NSLog(@"Entered username: %@",[[alertView textFieldAtIndex:0]text]);
        NSLog(@"Entered password: %@",[[alertView textFieldAtIndex:1]text]);
        
        DeveloperAuthenticationClient *idPClient = [[DeveloperAuthenticationClient alloc] init];
        AWSTask *task;
        task = [idPClient login:[[alertView textFieldAtIndex:0]text] password:[[alertView textFieldAtIndex:1]text]];
         [task continueWithBlock:^id(AWSTask *task) {
            if (task.error){
                NSLog(@"idPClient login failure: %@",task.error);
                return task.error;
            }
            else {
                NSLog(@"Result: %@",task.result);
                
                if ([[AWSClientHelper sharedInstance] getIdentityId]){
                    [self performSegueWithIdentifier:@"InfoViewSegue" sender:self];
                }else{
                    [[alertView textFieldAtIndex:0] resignFirstResponder];
                    [[alertView textFieldAtIndex:1] resignFirstResponder];
                    UIAlertView *alert = alert = [[UIAlertView alloc] initWithTitle:@"Logging in\nPlease Wait..." message:nil delegate:self cancelButtonTitle:nil otherButtonTitles: nil];
                    //Dispatch alert on main thread to avoid delays
                    [alert performSelectorOnMainThread:@selector(show) withObject:nil waitUntilDone:YES];
                    
                    UIActivityIndicatorView *indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
                    
                    // Adjust the indicator so it is up a few pixels from the bottom of the alert
                    indicator.center = CGPointMake(alert.bounds.size.width / 2, alert.bounds.size.height - 50);
                    [indicator startAnimating];
                    [alert addSubview:indicator];
                    
                    [NSThread sleepForTimeInterval:10.f];
                    
                    if ([[AWSClientHelper sharedInstance] getIdentityId]) {
                        [self performSegueWithIdentifier:@"InfoViewSegue" sender:self];
                    }else {
                        //Login failed
                        [[alertView textFieldAtIndex:0] resignFirstResponder];
                        [[alertView textFieldAtIndex:1] resignFirstResponder];
                        UIAlertView *alert = alert = [[UIAlertView alloc] initWithTitle:@"Loggin FAILED\nPlease check network connectivity and Lambda Monitoring." message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
                        //Dispatch alert on main thread to avoid delays
                        [alert performSelectorOnMainThread:@selector(show) withObject:nil waitUntilDone:YES];
                        
                        UIActivityIndicatorView *indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
                        
                        // Adjust the indicator so it is up a few pixels from the bottom of the alert
                        indicator.center = CGPointMake(alert.bounds.size.width / 2, alert.bounds.size.height - 50);
                        [indicator startAnimating];
                        [alert addSubview:indicator];
                        [NSThread sleepForTimeInterval:10.f];
                    }
                    
                    [alert dismissWithClickedButtonIndex:0 animated:YES];
                }
                return task.result;
            }
            return nil;
        }];
        NSLog(@"Result: %@",task.result);
        
    }else{
        NSLog(@"User clicked Cancel");
    }
}


#pragma mark FACEBOOK SECTION
-(void)loginButton:(FBSDKLoginButton *)loginButton didCompleteWithResult:(FBSDKLoginManagerLoginResult *)result error:(NSError *)error{
	NSLog(@"Username: %@",[FBSDKProfile currentProfile].name);
	NSLog(@"ID: %@",[FBSDKProfile currentProfile].userID);
	NSLog(@"Access token: %@", [FBSDKAccessToken currentAccessToken].tokenString);
    
#pragma warning clean this up later
    //Seems like we have to call login/logout/login before authentication works properly against Cognito. This might be a logic issue.
    AWSClientHelper *clientHelper = [AWSClientHelper sharedInstance];
    NSDictionary *fblogon = @{@"graph.facebook.com":[FBSDKAccessToken currentAccessToken].tokenString};
    [clientHelper linkLoginsToAuthenticate:fblogon];
    [self fetchUserInfo];
	
	//Check Cognito Authentication with Facebook before continuing to InfoViewController
	if ([[AWSClientHelper sharedInstance] getIdentityId]){
		[self performSegueWithIdentifier:@"InfoViewSegue" sender:self];
	}else{

		UIAlertView *alert = alert = [[UIAlertView alloc] initWithTitle:@"Logging in\nPlease Wait..." message:nil delegate:self cancelButtonTitle:nil otherButtonTitles: nil];
		//Dispatch alert on main thread to avoid delays
		[alert performSelectorOnMainThread:@selector(show) withObject:nil waitUntilDone:YES];
		
		UIActivityIndicatorView *indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
		
		// Adjust the indicator so it is up a few pixels from the bottom of the alert
		indicator.center = CGPointMake(alert.bounds.size.width / 2, alert.bounds.size.height - 50);
		[indicator startAnimating];
		[alert addSubview:indicator];
		
		[NSThread sleepForTimeInterval:10.f];
		
		if ([[AWSClientHelper sharedInstance] getIdentityId]) {
			[self performSegueWithIdentifier:@"InfoViewSegue" sender:self];
		}else {
			//Login failed
			UIAlertView *alert = alert = [[UIAlertView alloc] initWithTitle:@"Loggin FAILED\nPlease check network connectivity and Lambda Monitoring." message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
			//Dispatch alert on main thread to avoid delays
			[alert performSelectorOnMainThread:@selector(show) withObject:nil waitUntilDone:YES];
			
			UIActivityIndicatorView *indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
			
			// Adjust the indicator so it is up a few pixels from the bottom of the alert
			indicator.center = CGPointMake(alert.bounds.size.width / 2, alert.bounds.size.height - 50);
			[indicator startAnimating];
			[alert addSubview:indicator];
			[NSThread sleepForTimeInterval:10.f];
		}
		
		[alert dismissWithClickedButtonIndex:0 animated:YES];
	}
}

-(void)loginButtonDidLogOut:(FBSDKLoginButton *)loginButton{
	NSLog(@"Logging out of Facebook");
}

-(void)fetchUserInfo {
    [[[FBSDKGraphRequest alloc] initWithGraphPath:@"me" parameters:nil]
     startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id result, NSError *error) {
         if (!error) {
             NSLog(@"fetched user:%@", result);
         }
     }];
}


#pragma mark QRCode scanner SECTION
- (void) didSuccessfullyScan:(NSString *)aScannedValue{
	NSLog(@"Scanned successfully! The value is %@",aScannedValue);
	
	/*Strip out whitespace and remove quotes before passing to requestWithURL:*/
	NSString *Url = [aScannedValue stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	NSString *newString = [Url stringByReplacingOccurrencesOfString:@"\"" withString:@""];
	NSLog(@"newString: %@",newString);
	
	NSURLRequest *request = [NSURLRequest requestWithURL:
							 [NSURL URLWithString:newString]];
    __unused NSURLConnection *fetchConn = [[NSURLConnection alloc] initWithRequest:request
                                                                          delegate:self];

}

#pragma mark NSURLConnection Delegate Methods
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
	// A response has been received, this is where we initialize the instance var you created
	// so that we can append data to it in the didReceiveData method
	// Furthermore, this method is called each time there is a redirect so reinitializing it
	// also serves to clear it
	_responseData = [[NSMutableData alloc] init];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	// Append the new data to the instance variable you declared
	[_responseData appendData:data];
}

- (NSCachedURLResponse *)connection:(NSURLConnection *)connection
				  willCacheResponse:(NSCachedURLResponse*)cachedResponse {
	// Return nil to indicate not necessary to store a cached response for this connection
	return nil;
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
	NSLog(@"-connectionDidFinishLoading: received %lu bytes of data",(unsigned long)[_responseData length]);
    if ([_responseData length] < 100){
        NSLog(@"Bad data returned from %@",centralURL);
        return;
    }

    //Phone already tethered cleanup first before updating values
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
    if ([preferences objectForKey:@"cognitoIdentityPoolId"]){
        NSLog(@"Existing cognitoIdentityPoolId detected: %@ \nNeed to cleanup present values", [preferences objectForKey:@"cognitoIdentityPoolId"]);
        [self previousTetherCleanup];
    }
    
	// convert to JSON
	NSError *myError = nil;
	NSDictionary *res = [NSJSONSerialization JSONObjectWithData:_responseData options:NSJSONReadingMutableLeaves error:&myError];
	
    if (res){
        
        //Output values for debugging
        for(id key in res) {
            id value = [res objectForKey:key];
            NSString *keyAsString = (NSString *)key;
            NSString *valueAsString = (NSString *)value;
            NSLog(@"key: %@", keyAsString);
            NSLog(@"value: %@", valueAsString);
            [preferences setValue:valueAsString forKey:keyAsString];    //Store each returned value
        }
        
        NSMutableString *uniqueDatasetName = [NSMutableString stringWithFormat:[preferences objectForKey:@"cognitoDatasetName"]];
        [uniqueDatasetName appendString:@"_"];
        [uniqueDatasetName appendString:[preferences objectForKey:@"applianceId"]];
        NSLog(@"uniqueDatasetName: %@",[preferences objectForKey:@"uniqueDatasetName"]);
        [preferences setValue:uniqueDatasetName forKey:@"uniqueDatasetName"];
        
        const BOOL didSave = [preferences synchronize];					//Save Shared Preferences to disk
        
        if (!didSave){
            NSLog(@"Saving preferences failed");
        }else{
            [self performSelectorOnMainThread:@selector(tetherSuccess)
                                   withObject:nil
                                waitUntilDone:YES];
        }
    }else{
        NSLog(@"Bad input");
        return;
    }
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
	NSLog(@"didFailWithError: %@",[error description]);
}


@end
