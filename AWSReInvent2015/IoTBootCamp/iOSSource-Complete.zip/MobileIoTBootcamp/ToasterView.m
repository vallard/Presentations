//
//  ToasterView.m
//  MobileIoTBootcamp
//
//  Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License").
//  You may not use this file except in compliance with the License.
//  A copy of the License is located at
//
//  http://aws.amazon.com/apache2.0
//
//  or in the "license" file accompanying this file. This file is distributed
//  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
//  express or implied. See the License for the specific language governing
//  permissions and limitations under the License.
//
//  This source code forms part of the codebase for the re:Invent 2015 Bootcamp - "Creating applications for Mobile and IoT"
//
//  Created by Richard Threlkeld on 7/20/15.
//

#import "ToasterView.h"
#import "MicrowaveView.h"
#import "AWSCore.h"
#import "AWSCognito.h"
#import <AWSMobileAnalytics/AWSMobileAnalytics.h>
#import "AWSClientHelper.h"

const float TOASTTIME_MIN = 10;
const float TOASTTIME_MAX = 60;
const float DARKNESS_MIN = 1;
const float DARKNESS_MAX = 100;

@implementation ToasterView

@synthesize toastDarknessKey;
@synthesize toastWarmtimeKey;

- (void)viewDidLoad{
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(CognitoSyncUpdate) name:@"CognitoSyncUpdate" object:nil];
    
    NSMutableString *toastDarkness = [NSMutableString stringWithFormat:
                                   [NSBundle mainBundle].bundleIdentifier];
    [toastDarkness appendString:@".toastDarkness"];
    
    NSMutableString *toastWarmtime = [NSMutableString stringWithFormat:
                                  [NSBundle mainBundle].bundleIdentifier];
    [toastWarmtime appendString:@".toastWarmtime"];
    
    toastDarknessKey = [NSString stringWithString:toastDarkness];
    toastWarmtimeKey = [NSString stringWithString:toastWarmtime];
    
    AWSCognito *syncClient = [AWSCognito defaultCognito];
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
    AWSCognitoDataset *dataset = [syncClient openOrCreateDataset:
                                  [preferences objectForKey:@"uniqueDatasetName"]];
    [dataset synchronize];
    
    self.toastDarkness.maximumValue = (int)(DARKNESS_MAX - DARKNESS_MIN);
    self.toastWarmtime.maximumValue = (int)(TOASTTIME_MAX - TOASTTIME_MIN);
    
    self.toastDarkness.value = [self calcTempValueSliderFromCognito:
                             [dataset stringForKey:toastDarknessKey].intValue];
    
    self.toastWarmtime.value = [self calcTimeSliderFromCognito:
                            [dataset stringForKey:toastWarmtimeKey].intValue];
    
    self.darknessSettingLabel.text = [self getDarknessHumanRadable:
                                      [dataset stringForKey:toastDarknessKey].intValue];
    
    self.timeSettingLabel.text = [NSString stringWithFormat:@"%d",(int)[self calcTimeSliderFromCognito:
                                                                        [dataset stringForKey:toastWarmtimeKey].intValue]];
}

- (void) viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:NO];
}

- (int) calcTimeSliderProgress:(float)progress{
    return (int)(TOASTTIME_MIN + progress);
}

- (float) calcTimeSliderFromCognito:(int)time{
    return (time - TOASTTIME_MIN);
}

- (int) calcTempValueSliderProgress:(float)progress{
    return (int)(DARKNESS_MIN + progress);
}

- (float) calcTempValueSliderFromCognito:(int)time{
    return (time - DARKNESS_MIN);
}

- (NSString*) getDarknessHumanRadable:(int)percentage{
    if (percentage<10) {
        return @"Very Light";
    }else if (percentage < 30){
        return @"Light";
    }else if (percentage < 50){
        return @"Medium";
    }else if (percentage < 70){
        return @"Dark";
    }else{
        return @"Very Dark";
    }
}

-(void)CognitoSyncUpdate
{
    AWSCognito *syncClient = [AWSCognito defaultCognito];
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
    AWSCognitoDataset *dataset = [syncClient openOrCreateDataset:[preferences objectForKey:@"uniqueDatasetName"]];
    [dataset synchronize];
    
    self.toastDarkness.value = [dataset stringForKey:toastDarknessKey].floatValue;
    self.toastWarmtime.value = [dataset stringForKey:toastWarmtimeKey].floatValue;
    self.darknessSettingLabel.text = [self getDarknessHumanRadable:
                                      [dataset stringForKey:toastDarknessKey].intValue];
    self.timeSettingLabel.text = [NSString stringWithFormat:@"%d",[dataset stringForKey:toastWarmtimeKey].intValue];
}

- (IBAction)returnToDeviceScreen:(id)sender {
    [self.presentingViewController dismissViewControllerAnimated:YES completion:NULL];
}

- (IBAction)controlPanelValueChanged:(id)sender{
    NSLog(@"Setting local dataset values \ntoastDarkness: %d\ntoastWarmtime: %d",(int)self.toastDarkness.value,(int)self.toastWarmtime.value);
    AWSCognito *syncClient = [AWSCognito defaultCognito];
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
    AWSCognitoDataset *dataset = [syncClient openOrCreateDataset:[preferences objectForKey:@"uniqueDatasetName"]];
    
    [dataset setString:[NSString stringWithFormat:@"%d",(int)self.toastDarkness.value] forKey:toastDarknessKey];
    [dataset setString:[NSString stringWithFormat:@"%d",(int)self.toastWarmtime.value] forKey:toastWarmtimeKey];
    self.darknessSettingLabel.text = [self getDarknessHumanRadable:self.toastDarkness.value];
    self.timeSettingLabel.text = [NSString stringWithFormat:@"%d",(int)self.toastWarmtime.value];
}

- (NSString*)getPanelNameForAnalytics{
    return @"ToasterControlPanel";
}


- (IBAction)updateButton:(id)sender {
    AWSCognito *syncClient = [AWSCognito defaultCognito];
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
    
	//Sync Cognito Dataset
	AWSCognitoDataset *dataset = [syncClient openOrCreateDataset:[preferences objectForKey:@"uniqueDatasetName"]];
	NSLog(@"Synchronizing dataset with Cognito");
	[dataset synchronize];
	
	//Send data to Mobile Analytics
	AWSMobileAnalytics *analytics = [[AWSClientHelper sharedInstance] analytics:[preferences objectForKey:@"mobileanalyticsAppId"]];
	id<AWSMobileAnalyticsEventClient> eventClient = analytics.eventClient;
	id<AWSMobileAnalyticsEvent> customEvent = [eventClient createEventWithEventType:[self getPanelNameForAnalytics]];
	
	[customEvent addMetric:[NSNumber numberWithFloat:
							[self calcTempValueSliderProgress:
							 self.toastDarkness.value]] forKey:@"MaxTemp"];
	
	[customEvent addMetric:[NSNumber numberWithFloat:
							[self calcTimeSliderProgress:
							 self.toastWarmtime.value]] forKey:@"Time"];
	
	[eventClient recordEvent:customEvent];
	NSLog(@"Sending temperature and  events to Moble Analytics");
	[eventClient submitEvents];
	
}


@end
