//
//  BaseCPView.m
//  MobileIoTBootcamp
//
//  Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License").
//  You may not use this file except in compliance with the License.
//  A copy of the License is located at
//
//  http://aws.amazon.com/apache2.0
//
//  or in the "license" file accompanying this file. This file is distributed
//  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
//  express or implied. See the License for the specific language governing
//  permissions and limitations under the License.
//
//  This source code forms part of the codebase for the re:Invent 2015 Bootcamp - "Creating applications for Mobile and IoT"
//
//  Created by Richard Threlkeld on 7/20/15.
//

#import "BaseCPView.h"
#import <AWSMobileAnalytics/AWSMobileAnalytics.h>
#import <StoreKit/StoreKit.h>
#import "AWSClientHelper.h"
#import "InfoViewController.h"

@implementation BaseCPView

@synthesize datePanelStarted;

- (void) viewDidLoad{
    [super viewDidLoad];
    
    //SKUs for charging each time panel is launched
    NSArray *arraySKUs = [NSArray arrayWithObjects:@"SKU_1",
                          @"SKU_2",
                          @"SKU_3",
                          @"SKU_4",
                          @"SKU_5",
                          @"SKU_6",
                          @"SKU_7",
                          @"SKU_8",
                          @"SKU_9",
                          @"SKU_10", nil];
    
    int skuIndex = arc4random()%10;
    [self chargeWithSku:[arraySKUs objectAtIndex:skuIndex] andPrice:0.99];

    //Setup control panel image and title from tethered values
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    InfoViewController *info = [[InfoViewController alloc]init];
    //[self.controlPanelImage setImage:[UIImage imageNamed:[info getApplianceImage:[prefs objectForKey:@"applianceType"]]]];
    NSMutableString *title = [NSMutableString string];
    [title appendString:[info getApplianceName:[prefs objectForKey:@"applianceType"]]];
    [title appendString:@" Control Panel"];
    self.controlPanelTitle.text = title;
    
    //Start recording how long control panel is open
    datePanelStarted = [NSDate date];
}

- (void) viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:NO];
    [self recordAnalytics];
}

- (void) recordAnalytics{
    NSTimeInterval countSecondsPanelVisible = [[NSDate date] timeIntervalSinceDate:datePanelStarted];

    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    AWSMobileAnalytics *analytics = [[AWSClientHelper sharedInstance] analytics:[prefs objectForKey:@"mobileanalyticsAppId"]];
    id<AWSMobileAnalyticsEventClient> eventClient = analytics.eventClient;
    id<AWSMobileAnalyticsEvent> panelEvent = [eventClient createEventWithEventType:[self getPanelNameForAnalytics]];
    
    [panelEvent addAttribute:@"identity" forKey:[[AWSClientHelper sharedInstance] getIdentityId]];
    [panelEvent addMetric:[NSNumber numberWithDouble:countSecondsPanelVisible] forKey:@"TimeVisible"];
    
    NSLog(@"Recording amount of time panel was open: %f",countSecondsPanelVisible);
    [eventClient recordEvent:panelEvent];
    [eventClient submitEvents];
}

- (void) chargeWithSku:(NSString*)sku andPrice:(double)price{
    NSLog(@"Recording monetization event in Mobile Analytics for sku: %@",sku);
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    AWSMobileAnalytics *analytics = [[AWSClientHelper sharedInstance] analytics:[prefs objectForKey:@"mobileanalyticsAppId"]];

    id<AWSMobileAnalyticsEventClient> eventClient = analytics.eventClient;
    AWSMobileAnalyticsAppleMonetizationEventBuilder *builder = [AWSMobileAnalyticsAppleMonetizationEventBuilder builderWithEventClient:eventClient];
    
    [builder withProductId:sku];
    NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    [builder withItemPrice:price andPriceLocale:usLocale];
    [builder withQuantity:1.0];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc]init];
    [dateFormat setDateFormat:@"yyyy-MM-dd-hh:mm:ss"];
    [builder withTransactionId:[dateFormat stringFromDate:[NSDate date]]];
    [builder prepareForInterfaceBuilder];
    
    id<AWSMobileAnalyticsEvent> purchaseEvent = [builder build];
    [eventClient recordEvent:purchaseEvent];
    
    [eventClient submitEvents];
}

@end
