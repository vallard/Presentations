//
//  DeveloperAuthenticatedIdentityProvider.h
//  MobileIoTBootcamp
//
//  Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License").
//  You may not use this file except in compliance with the License.
//  A copy of the License is located at
//
//  http://aws.amazon.com/apache2.0
//
//  or in the "license" file accompanying this file. This file is distributed
//  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
//  express or implied. See the License for the specific language governing
//  permissions and limitations under the License.
//
//  This source code forms part of the codebase for the re:Invent 2015 Bootcamp - "Creating applications for Mobile and IoT"
//
//  Created by Richard Threlkeld on 7/20/15.
//
//  NOTE: This code is not to be considered production-ready since it is a simplified implementation of Developer Authentication through Cognito, for instructional purposes only.
// For a full implementation, see http://mobile.awsblog.com/post/Tx3E3NJURV1LNV1/Integrating-Amazon-Cognito-using-developer-authenticated-identities-An-end-to-en


#import "AWSIdentityProvider.h"

@class DeveloperAuthenticationClient;

@interface DeveloperAuthenticatedIdentityProvider : AWSAbstractCognitoIdentityProvider

@property (strong, atomic, readonly) DeveloperAuthenticationClient *client;

- (instancetype)initWithRegionType:(AWSRegionType)regionType
                        identityId:(NSString *)identityId
                    identityPoolId:(NSString *)identityPoolId
                            logins:(NSDictionary *)logins
                      providerName:(NSString *)providerName
                        authClient:(DeveloperAuthenticationClient *)client;

@end
