//
//  AppDelegate.m
//  MobileIoTBootcamp
//
//  Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License").
//  You may not use this file except in compliance with the License.
//  A copy of the License is located at
//
//  http://aws.amazon.com/apache2.0
//
//  or in the "license" file accompanying this file. This file is distributed
//  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
//  express or implied. See the License for the specific language governing
//  permissions and limitations under the License.
//
//  This source code forms part of the codebase for the re:Invent 2015 Bootcamp - "Creating applications for Mobile and IoT"
//
//  Created by Richard Threlkeld on 7/20/15.
//

#import "AppDelegate.h"
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import "ChatViewController.h"
#include "InfoViewController.h"


@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)addMessageFromRemoteNotification:(NSDictionary*)json updateUI:(BOOL)updateUI
{
    //get a pointer to Chat class to live update screen when APNS notification recieved
    UINavigationController *navigationController = (UINavigationController*)_window.rootViewController;
    if ([navigationController.viewControllers count]>2){
        ChatViewController *chatViewController =
        (ChatViewController*)[navigationController.viewControllers  objectAtIndex:2];
    
        DataModel *dataModel = chatViewController.dataModel;
        Message *message = [[Message alloc] init];
        message.date = [NSDate date];
    
        message.senderName = [json objectForKey:@"subject"];
        message.text = [json objectForKey:@"body"];
        
        int index = [dataModel addMessage:message];
        
        if (updateUI){
            [chatViewController didSaveMessage:message atIndex:index];
        }
    }
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    //Push notification setup below
    UIMutableUserNotificationAction *readAction = [UIMutableUserNotificationAction new];
    readAction.identifier = @"READ_IDENTIFIER";
    readAction.title = @"Read";
    readAction.activationMode = UIUserNotificationActivationModeForeground;
    readAction.destructive = NO;
    readAction.authenticationRequired = YES;
    
    UIMutableUserNotificationAction *deleteAction = [UIMutableUserNotificationAction new];
    deleteAction.identifier = @"DELETE_IDENTIFIER";
    deleteAction.title = @"Delete";
    deleteAction.activationMode = UIUserNotificationActivationModeForeground;
    deleteAction.destructive = YES;
    deleteAction.authenticationRequired = YES;
    
    UIMutableUserNotificationAction *ignoreAction = [UIMutableUserNotificationAction new];
    ignoreAction.identifier = @"IGNORE_IDENTIFIER";
    ignoreAction.title = @"Ignore";
    ignoreAction.activationMode = UIUserNotificationActivationModeForeground;
    ignoreAction.destructive = NO;
    ignoreAction.authenticationRequired = NO;
    
    UIMutableUserNotificationCategory *messageCategory = [UIMutableUserNotificationCategory new];
    messageCategory.identifier = @"MESSAGE_CATEGORY";
    [messageCategory setActions:@[readAction, deleteAction] forContext:UIUserNotificationActionContextMinimal];
    [messageCategory setActions:@[readAction, deleteAction, ignoreAction] forContext:UIUserNotificationActionContextDefault];
    
    UIUserNotificationType types = UIUserNotificationTypeBadge | UIUserNotificationTypeSound | UIUserNotificationTypeAlert;
    UIUserNotificationSettings *notificationSettings = [UIUserNotificationSettings settingsForTypes:types categories:[NSSet setWithArray:@[messageCategory]]];
    
    [[UIApplication sharedApplication] registerUserNotificationSettings:notificationSettings];
    [[UIApplication sharedApplication] registerForRemoteNotifications];
    
    //Facebook setup below
	[FBSDKLoginButton class];
	return [[FBSDKApplicationDelegate sharedInstance] application:application didFinishLaunchingWithOptions:launchOptions];
}

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    NSString *deviceTokenString = [[[deviceToken description] stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"<>"]] stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    NSLog(@"deviceTokenString: %@", deviceTokenString);
    [[NSUserDefaults standardUserDefaults] setObject:deviceTokenString forKey:@"deviceToken"];
    [[NSUserDefaults standardUserDefaults] setObject:deviceToken forKey:@"deviceTokenData"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    NSLog(@"Failed to register with error: %@",error);
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
    NSLog(@"didRecieveRemoteNotification in AppDelegate called: %@",userInfo);
    
    NSString *alertValue = [[userInfo valueForKey:@"aps"] valueForKey:@"alert"];
    NSLog(@"alertValue: %@",alertValue);
    
    NSError *jsonError;
    NSData *objectData = [alertValue dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                         options:NSJSONReadingMutableContainers
                                                           error:&jsonError];
    
    if ([json objectForKey:@"messageType"]) {
        NSLog(@"messageType: %@",[json objectForKey:@"messageType"]);

        switch ([[json objectForKey:@"messageType"] integerValue]) {
            case 1:
                NSLog(@"Call a chat message");
                [self addMessageFromRemoteNotification:json updateUI:YES];
                break;
            case 2:
                NSLog(@"System message");
                break;
            case 3:
                NSLog(@"Echo recieved");
                [[NSNotificationCenter defaultCenter] postNotificationName:@"showSNSPublish" object:nil];
                break;
            case 4:
                NSLog(@"ACK recieved from chat");
                break;
            case 5:
                NSLog(@"Pair completed");
                [[NSNotificationCenter defaultCenter] postNotificationName:@"pairingComplete"
                                                                    object:self
                                                                  userInfo:nil];
            default:
                break;
        }
    }else{
        NSLog(@"messageType does not exist - checking cognitoSync");
        NSString *cognitoSyncPush = [[userInfo valueForKey:@"data"] valueForKey:@"source"];
        if ([cognitoSyncPush isEqualToString:@"cognito-sync"]) {
            NSLog(@"cognito-sync command detected from APNS - calling Dataset sync");
            
            AWSCognito *syncClient = [AWSCognito defaultCognito];
            NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
            AWSCognitoDataset *dataset = [syncClient openOrCreateDataset:[preferences objectForKey:@"uniqueDatasetName"]];
            //Due to timing between dataset writing to disk and NSNotificationCenter broadcasting we synch twice and sleep for 1 second to allow new values to be written to SDCard
            [dataset synchronize];
            [NSThread sleepForTimeInterval:1.f];
            [dataset synchronize];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:@"CognitoSyncUpdate" object:nil];
        }
    }
}


- (void)applicationWillResignActive:(UIApplication *)application {
	// Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
	// Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
	// Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
	// If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
	// Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
	[FBSDKAppEvents activateApp];
}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation{
	return [[FBSDKApplicationDelegate sharedInstance] application:application openURL:url sourceApplication:sourceApplication annotation:annotation];
}

- (void)applicationWillTerminate:(UIApplication *)application {
	// Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
