//
//  MicrowaveView.m
//  MobileIoTBootcamp
//
//  Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License").
//  You may not use this file except in compliance with the License.
//  A copy of the License is located at
//
//  http://aws.amazon.com/apache2.0
//
//  or in the "license" file accompanying this file. This file is distributed
//  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
//  express or implied. See the License for the specific language governing
//  permissions and limitations under the License.
//
//  This source code forms part of the codebase for the re:Invent 2015 Bootcamp - "Creating applications for Mobile and IoT"
//
//  Created by Richard Threlkeld on 7/20/15.
//

#import "MicrowaveView.h"
#import "AWSCore.h"
#import "AWSCognito.h"
#import <AWSMobileAnalytics/AWSMobileAnalytics.h>
#import "AWSClientHelper.h"

const float MICROTIME_MIN = 10;
const float MICROTIME_MAX = 60;
const float POWER_MIN = 1;
const float POWER_MAX = 100;

@implementation MicrowaveView

@synthesize microPowerKey;
@synthesize microTimeKey;

- (void)viewDidLoad{
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(CognitoSyncUpdate) name:@"CognitoSyncUpdate" object:nil];
    
    NSMutableString *microPower = [NSMutableString stringWithFormat:
                                  [NSBundle mainBundle].bundleIdentifier];
    [microPower appendString:@".microPower"];
    
    NSMutableString *microTime = [NSMutableString stringWithFormat:
                                     [NSBundle mainBundle].bundleIdentifier];
    [microTime appendString:@".microTime"];
    
    microPowerKey = [NSString stringWithString:microPower];
    microTimeKey = [NSString stringWithString:microTime];
    
    AWSCognito *syncClient = [AWSCognito defaultCognito];
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
    AWSCognitoDataset *dataset = [syncClient openOrCreateDataset:
                                  [preferences objectForKey:@"uniqueDatasetName"]];
    [dataset synchronize];
    
    self.microPower.maximumValue = (int)(POWER_MAX - POWER_MIN);
    self.microTime.maximumValue = (int)(MICROTIME_MAX - MICROTIME_MIN);

    self.microPower.value = [self calcTempValueSliderFromCognito:
                            [dataset stringForKey:microPowerKey].intValue];
    
    self.microTime.value = [self calcTimeSliderFromCognito:
                               [dataset stringForKey:microTimeKey].intValue];
    
    self.powerSettingLabel.text = [self getPowerHumanRadable:
                                   [dataset stringForKey:microPowerKey].intValue];
    
    self.timeSettingLabel.text = [NSString stringWithFormat:@"%d",(int)[self calcTimeSliderFromCognito:
                                                                   [dataset stringForKey:microTimeKey].intValue]];
}

- (void) viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:NO];
}

- (int) calcTimeSliderProgress:(float)progress{
    return (int)(MICROTIME_MIN + progress);
}

- (float) calcTimeSliderFromCognito:(int)time{
    return (time - MICROTIME_MIN);
}

- (int) calcTempValueSliderProgress:(float)progress{
    return (int)(POWER_MIN + progress);
}

- (float) calcTempValueSliderFromCognito:(int)time{
    return (time - POWER_MIN);
}

- (NSString*) getPowerHumanRadable:(int)percentage{
    if (percentage<10) {
        return @"Very Low";
    }else if (percentage < 30){
        return @"Low";
    }else if (percentage < 50){
        return @"Medium";
    }else if (percentage < 70){
        return @"High";
    }else{
        return @"Very High";
    }
}

-(void)CognitoSyncUpdate
{
    AWSCognito *syncClient = [AWSCognito defaultCognito];
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
    AWSCognitoDataset *dataset = [syncClient openOrCreateDataset:[preferences objectForKey:@"uniqueDatasetName"]];
    [dataset synchronize];
    
    self.microPower.value = [dataset stringForKey:microPowerKey].floatValue;
    self.microTime.value = [dataset stringForKey:microTimeKey].floatValue;
    self.powerSettingLabel.text = [self getPowerHumanRadable:
                                   [dataset stringForKey:microPowerKey].intValue];
    self.timeSettingLabel.text = [NSString stringWithFormat:@"%d",[dataset stringForKey:microTimeKey].intValue];
}

- (IBAction)returnToDeviceScreen:(id)sender {
    [self.presentingViewController dismissViewControllerAnimated:YES completion:NULL];
}

- (IBAction)controlPanelValueChanged:(id)sender{
    NSLog(@"Setting local dataset values \nmicroPower: %d\nmicroTime: %d",(int)self.microPower.value,(int)self.microTime.value);
    AWSCognito *syncClient = [AWSCognito defaultCognito];
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
    AWSCognitoDataset *dataset = [syncClient openOrCreateDataset:[preferences objectForKey:@"uniqueDatasetName"]];
    
    [dataset setString:[NSString stringWithFormat:@"%d",(int)self.microPower.value] forKey:microPowerKey];
    [dataset setString:[NSString stringWithFormat:@"%d",(int)self.microTime.value] forKey:microTimeKey];
    self.powerSettingLabel.text = [self getPowerHumanRadable:self.microPower.value];
    self.timeSettingLabel.text = [NSString stringWithFormat:@"%d",(int)self.microTime.value];
}

- (NSString*)getPanelNameForAnalytics{
    return @"MicrowaveControlPanel";
}

- (IBAction)updateButton:(id)sender {
    AWSCognito *syncClient = [AWSCognito defaultCognito];
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
    
	//Sync Cognito Dataset
	AWSCognitoDataset *dataset = [syncClient openOrCreateDataset:[preferences objectForKey:@"uniqueDatasetName"]];
	NSLog(@"Synchronizing dataset with Cognito");
	[dataset synchronize];
	
	//Send data to Mobile Analytics
	AWSMobileAnalytics *analytics = [[AWSClientHelper sharedInstance] analytics:[preferences objectForKey:@"mobileanalyticsAppId"]];
	id<AWSMobileAnalyticsEventClient> eventClient = analytics.eventClient;
	id<AWSMobileAnalyticsEvent> customEvent = [eventClient createEventWithEventType:[self getPanelNameForAnalytics]];
	
	[customEvent addMetric:[NSNumber numberWithFloat:
							[self calcTempValueSliderProgress:
							 self.microPower.value]] forKey:@"MaxTemp"];
	
	[customEvent addMetric:[NSNumber numberWithFloat:
							[self calcTimeSliderProgress:
							 self.microTime.value]] forKey:@"Time"];
	
	[eventClient recordEvent:customEvent];
	NSLog(@"Sending temperature and  events to Moble Analytics");
	[eventClient submitEvents];
	
}


@end
