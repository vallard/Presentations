//
//  BlenderView.m
//  MobileIoTBootcamp
//
//  Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License").
//  You may not use this file except in compliance with the License.
//  A copy of the License is located at
//
//  http://aws.amazon.com/apache2.0
//
//  or in the "license" file accompanying this file. This file is distributed
//  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
//  express or implied. See the License for the specific language governing
//  permissions and limitations under the License.
//
//  This source code forms part of the codebase for the re:Invent 2015 Bootcamp - "Creating applications for Mobile and IoT"
//
//  Created by Richard Threlkeld on 7/20/15.
//

#import "BlenderView.h"
#import "AWSCore.h"
#import "AWSCognito.h"
#import <AWSMobileAnalytics/AWSMobileAnalytics.h>
#import "AWSClientHelper.h"

const float BLENDTIME_MIN = 1;
const float BLENDTIME_MAX = 60;
const float BLENDSPEED_MIN = 1000;
const float BLENDSPEED_MAX = 6000;

@implementation BlenderView

@synthesize blendSpeedKey;
@synthesize blendTimeKey;

- (void)viewDidLoad{
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(CognitoSyncUpdate) name:@"CognitoSyncUpdate" object:nil];
    
    NSMutableString *blendSpeed = [NSMutableString stringWithFormat:
                                  [NSBundle mainBundle].bundleIdentifier];
    [blendSpeed appendString:@".blendSpeed"];
    
    NSMutableString *blendTime = [NSMutableString stringWithFormat:
                                     [NSBundle mainBundle].bundleIdentifier];
    [blendTime appendString:@".blendTime"];
    
    blendSpeedKey = [NSString stringWithString:blendSpeed];
    blendTimeKey = [NSString stringWithString:blendTime];
    
    AWSCognito *syncClient = [AWSCognito defaultCognito];
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
    AWSCognitoDataset *dataset = [syncClient openOrCreateDataset:
                                  [preferences objectForKey:@"uniqueDatasetName"]];
    [dataset synchronize];
    
    self.blendSpeed.maximumValue = (int)(BLENDSPEED_MAX - BLENDSPEED_MIN);
    self.blendTime.maximumValue = (int)(BLENDTIME_MAX - BLENDTIME_MIN);
    
    self.blendSpeed.value = [self calcSpeedValueSliderFromCognito:
                            [dataset stringForKey:blendSpeedKey].intValue];
    
    self.blendTime.value = [self calcblendTimeSliderFromCognito:
                               [dataset stringForKey:blendTimeKey].intValue];
    
    self.speedSettingLabel.text = [NSString stringWithFormat:@"%d", (int)[self calcSpeedValueSliderFromCognito:[dataset stringForKey:blendSpeedKey].intValue]];
    
    self.timeSettingLabel.text = [NSString stringWithFormat:@"%d", (int)[self calcblendTimeSliderFromCognito:[dataset stringForKey:blendTimeKey].intValue]];
}

- (void) viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:NO];
}

- (int) calcblendTimeSliderProgress:(float)progress{
    return (int)(BLENDTIME_MIN + progress);
}

- (float) calcblendTimeSliderFromCognito:(int)time{
    return (time - BLENDTIME_MIN);
}

- (int) calcTempValueSliderProgress:(float)progress{
    return (int)(BLENDSPEED_MIN + progress);
}

- (float) calcSpeedValueSliderFromCognito:(int)time{
    return (time - BLENDSPEED_MIN);
}

-(void)CognitoSyncUpdate
{
    AWSCognito *syncClient = [AWSCognito defaultCognito];
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
    AWSCognitoDataset *dataset = [syncClient openOrCreateDataset:[preferences objectForKey:@"uniqueDatasetName"]];
    [dataset synchronize];
    
    self.blendSpeed.value = [dataset stringForKey:blendSpeedKey].floatValue;
    self.blendTime.value = [dataset stringForKey:blendTimeKey].floatValue;
    self.speedSettingLabel.text = [NSString stringWithFormat:@"%d",[dataset stringForKey:blendSpeedKey].intValue];
    self.timeSettingLabel.text = [NSString stringWithFormat:@"%d",[dataset stringForKey:blendTimeKey].intValue];
}

- (IBAction)returnToDeviceScreen:(id)sender {
    [self.presentingViewController dismissViewControllerAnimated:YES completion:NULL];
}

- (IBAction)controlPanelValueChanged:(id)sender{
    NSLog(@"Setting local dataset values \nblendSpeed: %d\nblendTime: %d",(int)self.blendSpeed.value,(int)self.blendTime.value);
    AWSCognito *syncClient = [AWSCognito defaultCognito];
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
    AWSCognitoDataset *dataset = [syncClient openOrCreateDataset:[preferences objectForKey:@"uniqueDatasetName"]];
    
    [dataset setString:[NSString stringWithFormat:@"%d",(int)self.blendSpeed.value] forKey:blendSpeedKey];
    [dataset setString:[NSString stringWithFormat:@"%d",(int)self.blendTime.value] forKey:blendTimeKey];
    self.speedSettingLabel.text = [NSString stringWithFormat:@"%d",(int)self.blendSpeed.value];
    self.timeSettingLabel.text = [NSString stringWithFormat:@"%d",(int)self.blendTime.value];
}

- (NSString*)getPanelNameForAnalytics{
    return @"BlenderControlPanel";
}

- (IBAction)updateButton:(id)sender {
    AWSCognito *syncClient = [AWSCognito defaultCognito];
    NSUserDefaults *preferences = [NSUserDefaults standardUserDefaults];
    
	//Sync Cognito Dataset
	AWSCognitoDataset *dataset = [syncClient openOrCreateDataset:[preferences objectForKey:@"uniqueDatasetName"]];
	NSLog(@"Synchronizing dataset with Cognito");
	[dataset synchronize];
	
	//Send data to Mobile Analytics
	AWSMobileAnalytics *analytics = [[AWSClientHelper sharedInstance] analytics:[preferences objectForKey:@"mobileanalyticsAppId"]];
	id<AWSMobileAnalyticsEventClient> eventClient = analytics.eventClient;
	id<AWSMobileAnalyticsEvent> customEvent = [eventClient createEventWithEventType:[self getPanelNameForAnalytics]];
	
	[customEvent addMetric:[NSNumber numberWithFloat:
							[self calcTempValueSliderProgress:
							 self.blendSpeed.value]] forKey:@"MaxTemp"];
	
	[customEvent addMetric:[NSNumber numberWithFloat:
							[self calcblendTimeSliderProgress:
							 self.blendTime.value]] forKey:@"blendTime"];
	
	[eventClient recordEvent:customEvent];
	NSLog(@"Sending temperature and blend events to Moble Analytics");
	[eventClient submitEvents];

}

@end
