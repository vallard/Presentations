//
//  ChatViewController.m
//  MobileIoTBootcamp
//
//  Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License").
//  You may not use this file except in compliance with the License.
//  A copy of the License is located at
//
//  http://aws.amazon.com/apache2.0
//
//  or in the "license" file accompanying this file. This file is distributed
//  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
//  express or implied. See the License for the specific language governing
//  permissions and limitations under the License.
//
//  This source code forms part of the codebase for the re:Invent 2015 Bootcamp - "Creating applications for Mobile and IoT"
//
//  Created by Richard Threlkeld on 7/20/15.
//
/*Code based on chat example from Ray Wenderlich: http://www.raywenderlich.com/32963/apple-push-notification-services-in-ios-6-tutorial-part-2*/

#import "ChatViewController.h"
#import "DataModel.h"
#import "Message.h"
#import "MessageTableViewCell.h"
#import "SpeechBubbleView.h"
#import <AWSSQS/AWSSQS.h>
#import <AWSSNS/AWSSNS.h>

@implementation ChatViewController

@synthesize inputTextField;
@synthesize delegate;

- (IBAction)sendChatText:(id)sender {
    [self sendMessage:self.inputTextField.text
           sentByUser:YES];
    [self.inputTextField setText:@""];
    [self.view endEditing:YES];
}

- (id) initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        _dataModel = [[DataModel alloc] init];
        [_dataModel loadMessages];
    }
    return self;
}

- (void)scrollToNewestMessage
{
    // The newest message is at the bottom of the table
	NSIndexPath* indexPath = [NSIndexPath indexPathForRow:(self.dataModel.messages.count - 1) inSection:0];
	[self.chatTableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
    NSLog(@"scrollToNewestMessage: inside ChatViewController");
}

- (void) viewDidLoad{
    [super viewDidLoad];
    [self registerForKeyboardNotifications];
}

- (void) viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    
    if (!self.dataModel.messages.count == 0){
        [self scrollToNewestMessage];
    }else{
        [self sendMessage:@"Ready? Let's chat!" sentByUser:NO];
    }
}



- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
    
	self.title = [_dataModel secretCode];

	// Show a label in the table's footer if there are no messages
	if (self.dataModel.messages.count == 0)
	{
		UILabel* label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 30)];
		label.text = NSLocalizedString(@"You have no messages", nil);
		label.font = [UIFont boldSystemFontOfSize:16.0f];
		label.textAlignment = NSTextAlignmentCenter;
		label.textColor = [UIColor colorWithRed:76.0f/255.0f green:86.0f/255.0f blue:108.0f/255.0f alpha:1.0f];
		label.shadowColor = [UIColor whiteColor];
		label.shadowOffset = CGSizeMake(0.0f, 1.0f);
		label.backgroundColor = [UIColor clearColor];
		label.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
		self.chatTableView.tableFooterView = label;
	}
	else
	{
		[self scrollToNewestMessage];
	}
}

#pragma mark -
#pragma mark UITableViewDataSource

- (int)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section
{
	return self.dataModel.messages.count;
}

- (UITableViewCell*)tableView:(UITableView*)tableView cellForRowAtIndexPath:(NSIndexPath*)indexPath
{
	static NSString* CellIdentifier = @"MessageCellIdentifier";

	MessageTableViewCell* cell = (MessageTableViewCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil)
		cell = [[MessageTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];

	Message* message = (self.dataModel.messages)[indexPath.row];
	[cell setMessage:message];
	return cell;
}

#pragma mark -
#pragma mark UITableView Delegate

- (CGFloat)tableView:(UITableView*)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath
{
	// This function is called before cellForRowAtIndexPath, once for each cell.
	// We calculate the size of the speech bubble here and then cache it in the
	// Message object, so we don't have to repeat those calculations every time
	// we draw the cell. We add 16px for the label that sits under the bubble.
	Message* message = (self.dataModel.messages)[indexPath.row];
	message.bubbleSize = [SpeechBubbleView sizeForText:message.text];
	return message.bubbleSize.height + 16;
}

#pragma mark ComposeDelegate - Called via SNS when AppDelegate implements this protocol method

- (void)didSaveMessage:(Message*)message atIndex:(int)index
{
    // This method is called when a push notification from APNS is recieved
    NSLog(@"Inside didSaveMessage");
    if ([self isViewLoaded])
    {
        self.chatTableView.tableFooterView = nil;
        [self.chatTableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:index inSection:0]] withRowAnimation:UITableViewRowAnimationFade];
        [self viewDidAppear:YES];
        
        [self scrollToNewestMessage];
    }
}


#pragma mark sending message
- (void) sendMessage:(NSString *)messageText sentByUser:(BOOL)sentUser{
    NSLog(@"calling sendMessage");
    
    //Initialize pointer to local message store
    _dataModel = [[DataModel alloc] init];
    [_dataModel loadMessages];
    
    //Create a new message
    Message* message = [[Message alloc] init];
    message.date = [NSDate date];
    message.text = messageText;

    if (sentUser){
        message.senderName = nil;
    }
    
    AWSSQS *sqs = [AWSSQS defaultSQS];
    AWSSQSSendMessageRequest *messageRequest = [[AWSSQSSendMessageRequest alloc] init];
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    [messageRequest setQueueUrl:[prefs objectForKey:@"sqsUrlToEdison"]];
    
    CloudMessage *cloudMsg = [[CloudMessage alloc] init];
    
    NSDictionary *packet = [cloudMsg cloudMessage:1
                                                 :[[UIDevice currentDevice] name]
                                                 :messageText];
    
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:packet
                                                       options:0
                                                         error:&error];
    
    NSString *JSONString = [[NSString alloc] initWithBytes:[jsonData bytes]
                                                    length:[jsonData length]
                                                  encoding:NSUTF8StringEncoding];
    NSLog(@"JSON chat message body: %@",JSONString);
    
    CommandPacket *cmdPacket = [[CommandPacket alloc]init];
    NSDictionary *commandPacketWrapper = [cmdPacket commandPacket:4
                                                                 :@""
                                                                 :@""
                                                                 :JSONString];
    
    NSData *jsonCommandData = [NSJSONSerialization dataWithJSONObject:commandPacketWrapper
                                                       options:0
                                                         error:&error];
    
    NSString *jsonWrapperString = [[NSString alloc] initWithBytes:[jsonCommandData bytes]
                                                    length:[jsonCommandData length]
                                                  encoding:NSUTF8StringEncoding];
    
    NSLog(@"JSON wrapperString: %@",jsonWrapperString);
    [messageRequest setMessageBody:jsonWrapperString];
    
    //Send chat message to SQS Async to not slow user experience on chat screen
    [[sqs sendMessage:messageRequest] continueWithBlock:^id(AWSTask *task) {
        NSLog(@"Sent AWSTask SQS");
        if(task.error){
            NSLog(@"SQS Error: %@",task.error);
        }else{
            NSLog(@"SQS Result: %@",task.result);
        }
        return task.result;
    }];
    
    //Add message to local store and refresh chat UI
    int index = [_dataModel addMessage:message];
    if ([self isViewLoaded])
    {
        //self.tableView.tableFooterView = nil;
        [self.chatTableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:index inSection:0]] withRowAnimation:UITableViewRowAnimationFade];
        [self scrollToNewestMessage];
    }
}

#pragma keyboard show/hide when entering messages

// Call this method somewhere in your view controller setup code.
- (void)registerForKeyboardNotifications
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWasShown:)
                                                 name:UIKeyboardDidShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillBeHidden:)
                                                 name:UIKeyboardWillHideNotification object:nil];
}

// Called when the UIKeyboardDidShowNotification is sent.
- (void)keyboardWasShown:(NSNotification*)aNotification
{
    NSDictionary* info = [aNotification userInfo];
    CGRect keyPadFrame=[[UIApplication sharedApplication].keyWindow convertRect:[[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue] fromView:self.view];
    CGSize kbSize =keyPadFrame.size;
    CGRect activeRect=[self.view convertRect:inputTextField.frame fromView:inputTextField.superview];
    CGRect aRect = self.view.bounds;
    aRect.size.height -= (kbSize.height);
    
    CGPoint origin =  activeRect.origin;

    origin.y -= self.scrollView.contentOffset.y;
    if (!CGRectContainsPoint(aRect, origin)) {
        CGPoint scrollPoint = CGPointMake(0.0,CGRectGetMaxY(activeRect)-(aRect.size.height));
        [self.scrollView setContentOffset:scrollPoint animated:YES];
    }
}

// Called when the UIKeyboardWillHideNotification is sent
- (void)keyboardWillBeHidden:(NSNotification*)aNotification
{
    NSLog(@"Calling keyboardWillBeHidden:");
   
    UIEdgeInsets contentInsets = UIEdgeInsetsZero;
    self.scrollView.contentInset = contentInsets;
    self.scrollView.scrollIndicatorInsets = contentInsets;
    [self.scrollView setContentOffset:CGPointZero];
}

@end
